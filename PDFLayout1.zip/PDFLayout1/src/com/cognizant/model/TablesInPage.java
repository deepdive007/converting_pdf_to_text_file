package com.cognizant.model;

import java.util.ArrayList;
import java.util.List;

public class TablesInPage {
//this is the whole content of a single PDF Page
	List<SubTable> tableInPage;
	private double height;
	private double width;

	public TablesInPage() {
		this.tableInPage = new ArrayList<SubTable>();
	}

	public void add(SubTable subTable) {
		this.tableInPage.add(subTable);

	}

	public int getNoOfTables() {
		return this.tableInPage.size();

	}

	public boolean isEmpty() {
		if (this.tableInPage.size() == 0)
			return true;
		else
			return false;

	}

	public SubTable getSubTable(int subTableNo) {
		return this.tableInPage.get(subTableNo);

	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	@Override
	public String toString() {
		return "TablesInPage [tableinpage=" + tableInPage + ", height=" + height + ", width=" + width + "]";
	}

	
}
