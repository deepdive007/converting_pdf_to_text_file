package com.cognizant.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UtilityManager {

	public String removeStopWords(String description) {

		String[] stopWords = { "able", "about", "above", "according", "accordingly", "across", "actually", "after",
				"afterwards", "again", "against", "ain�t", "all", "allow", "allows", "almost", "alone", "along",
				"already", "also", "although", "always", "am", "among", "amongst", "an", "and", "another", "any",
				"anybody", "anyhow", "anyone", "anything", "anyway", "anyways", "anywhere", "apart", "appear",
				"appreciate", "appropriate", "are", "aren�t", "around", "as", "aside", "ask", "asking", "associated",
				"at", "available", "away", "awfully", "be", "became", "because", "become", "becomes", "becoming",
				"been", "before", "beforehand", "behind", "being", "believe", "below", "beside", "besides", "best",
				"better", "between", "beyond", "both", "brief", "but", "by", "c�mon", "c�s", "came", "can", "can�t",
				"cannot", "cant", "cause", "causes", "certain", "certainly", "changes", "clearly", "come", "comes",
				"cerning", "consequently", "consider", "considering", "contain", "containing", "contains",
				"corresponding", "could", "couldn�t", "course", "currently", "definitely", "descr", "bed", "despite",
				"did", "didn�t", "different", "do", "does", "doesn�t", "doing", "don�t", "done", "down", "downwards",
				"during", "each", "edu", "eg", "eight", "either", "else", "elsewhere", "enough", "entirely",
				"especially", "et", "etc", "even", "ever", "every", "everybody", "everyone", "everything", "everywhere",
				"ex", "exactly", "example", "except", "far", "few", "fifth", "five", "followed", "following", "follows",
				"for", "former", "formerly", "forth", "four", "from", "further", "furthermore", "get", "gets",
				"getting", "given", "gives", "go", "goes", "going", "gone", "got", "gotten", "greetings", "had",
				"hadn�t", "happens", "hardly", "has", "hasn�t", "have", "haven�t", "having", "he", "he�s", "he", "lo",
				"help", "hence", "her", "here", "here�s", "hereafter", "hereby", "herein", "hereupon", "hers",
				"herself", "hi", "him", "himself", "his", "hither", "hopefully", "how", "howb", "it", "however", "i�d",
				"i�ll", "i�m", "i�ve", "ie", "if", "ignored", "immediate", "inasmuch", "inc", "indeed", "indicate",
				"indicated", "indicates", "inner", "insofar", "i", "stead", "into", "inward", "is", "isn�t", "it",
				"it�d", "it�ll", "it�s", "its", "itself", "just", "keep", "keeps", "kept", "know", "knows", "known",
				"lately", "later", "lat", "er", "latterly", "least", "less", "lest", "let", "let�s", "like", "liked",
				"likely", "little", "look", "looking", "looks", "ltd", "mainly", "many", "may", "maybe", "me", "mean",
				"meanwhile", "merely", "might", "more", "moreover", "most", "mostly", "much", "must", "my", "myself",
				"namely", "nd", "near", "nearly", "necessary", "need", "needs", "neither", "never", "nevertheless",
				"new", "next", "nine", "no", "nobody", "non", "none", "noone", "nor", "normally", "not", "nothing",
				"novel", "now", "nowhere", "obviously", "of", "off", "often", "oh", "ok", "okay", "old", "on", "once",
				"one", "ones", "only", "onto", "or", "other", "others", "otherwise", "ought", "our", "ours",
				"ourselves", "out", "outside", "over", "overall", "own", "particular", "particularly", "per", "perhaps",
				"placed", "please", "plus", "possible", "presumably", "probably", "provides", "que", "quite", "qv",
				"rather", "rd", "re", "really", "reasonably", "regarding", "regardless", "regards", "relatively",
				"respectively", "right", "said", "same", "saw", "say", "saying", "says", "second", "secondly", "see",
				"seeing", "seem", "seemed", "seeming", "seems", "seen", "self", "selves", "sensible", "sent", "serious",
				"seriously", "seven", "several", "shall", "she", "should", "should", "�t", "since", "six", "so", "some",
				"somebody", "somehow", "someone", "something", "sometime", "sometimes", "somewhat", "somewhere", "soon",
				"sorry", "specified", "specify", "s", "ecifying", "still", "sub", "such", "sup", "sure", "t�s", "take",
				"taken", "tell", "tends", "th", "than", "thank", "thanks", "thanx", "that", "that�s", "thats", "the",
				"their", "th", "irs", "them", "themselves", "then", "thence", "there", "there�s", "thereafter",
				"thereby", "therefore", "therein", "theres", "thereupon", "these", "they", "they�d", "they�ll",
				"they�re", "they�ve", "think", "third", "this", "thorough", "thoroughly", "those", "though", "three",
				"through", "throughout", "thru", "thus", "to", "together", "too", "took", "t", "ward", "towards",
				"tried", "tries", "truly", "try", "trying", "twice", "two", "un", "under", "unfortunately", "unless",
				"unlikely", "until", "unto", "up", "upon", "us", "use", "u", "ed", "useful", "uses", "using", "usually",
				"value", "various", "very", "via", "viz", "vs", "want", "wants", "was", "wasn�t", "way", "we", "we�d",
				"we�ll", "we�re", "we�ve", "welco", "e", "well", "went", "were", "weren�t", "what", "what�s",
				"whatever", "when", "whence", "whenever", "where", "where�s", "whereafter", "whereas", "whereby",
				"wherein", "whereupon", "wherever", "whether", "which", "while", "whither", "who", "who�s", "whoever",
				"whole", "whom", "whose", "why", "will", "willing", "wish", "with", "within", "without", "won�t",
				"wonder", "would", "would", "wouldn�t", "yes", "yet", "you", "you�d", "you�ll", "you�re", "you�ve",
				"your", "yours", "yourself", "yourselves", "zero" };
		String value = "";
		Pattern p = Pattern.compile(".s");// . represents single character
		Matcher matcher = p.matcher("as");
		for (int j = 0; j < stopWords.length; j++) {
			value = stopWords[j];
			String s = "\\b" + value.trim() + "\\b";
			p = Pattern.compile(s, Pattern.CASE_INSENSITIVE);
			matcher = p.matcher(description);
			if (matcher.find()) {
				description = description.replaceAll(s, "").replaceAll("[\\s]+", " ");
			}
		}

		return description;
	}

	public int checkForBold(String fontFamily) {
		int isBold = 0;
		if (fontFamily.toLowerCase().contains("bold") || fontFamily.toLowerCase().endsWith(".b"))
//				|| fontFamily.toLowerCase().endsWith("boldmt")
//				|| fontFamily.toLowerCase().endsWith("boldextracondensed"))
			isBold = 1;
		return isBold;
	}

	public int checkForCapital(String text) {
		// returns 0 if all small; 1 if all caps;
		// 2 if first char of every word is caps
		int isCapital = 0;
		if (text.toLowerCase().equals(text)) {
			isCapital = 0;
		} else if (text.toUpperCase().equals(text)) {
			isCapital = 1;
		} else {
			String[] wordArray = text.trim().split("\\s+");
			for (String word : wordArray) {
				char c = word.charAt(0);
				if (c >= 97 && c <= 122) {
					isCapital = 0;
					return isCapital;
				} else {
					isCapital = 2;
				}
			}
		}
		return isCapital;
	}
	
	public void prepareTestingDataFile(String testData, String testingDataFile) {
		// TODO Auto-generated method stub
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(testingDataFile));
			bw.write(testData);
			bw.newLine();

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {

				bw.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}

	}
}
