package com.cognizant.model;

import java.util.ArrayList;
import java.util.List;

public class SubTable {
//content of each table
	List<Row> subTable;

	public SubTable() {
		this.subTable = new ArrayList<Row>();
	}

	public void add(Row row) {
		this.subTable.add(row);
	}

	public int getNoOfRows() {
		return this.subTable.size();
	}

	public int getMaxColSize() {
		return this.subTable.size();
	}

	public Row getrow(int rowno) {
		return this.subTable.get(rowno);

	}

	public boolean isEmpty() {
		if (this.subTable.size() == 0)
			return true;
		else
			return false;

	}

	/*
	 * public int getMaxNoCol() { int max = 0, freq = 0; List<Integer> colSize =
	 * new ArrayList<Integer>(); for (Row row : this.subtable) {
	 * colSize.add(row.getSize()); } HashSet<Integer> uniqueValues = new
	 * HashSet<Integer>(colSize); Iterator<Integer> iter =
	 * uniqueValues.iterator(); while (iter.hasNext()) { int val = iter.next();
	 * int valFreq = Collections.frequency(colSize, val); freq = freq > valFreq
	 * ? freq : valFreq; if (freq == valFreq) max = val; } return max; }
	 */

	@Override
	public String toString() {
		return "Subtable [subtable=" + subTable + "]";
	}
}
