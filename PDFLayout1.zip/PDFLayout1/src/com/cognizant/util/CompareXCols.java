package com.cognizant.util;

import java.util.Comparator;

import com.cognizant.model.RectAllPoint;

public class CompareXCols implements Comparator<RectAllPoint>{

	@Override
	public int compare(RectAllPoint r1, RectAllPoint r2) {
		//compare x of bottom left corner
		return (int) (r1.getP4().x - r2.getP4().x);
	}

}
