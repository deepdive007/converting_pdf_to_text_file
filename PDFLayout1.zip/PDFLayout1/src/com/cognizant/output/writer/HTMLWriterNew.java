package com.cognizant.output.writer;

import java.util.Collections;
import java.util.Map;
import java.util.Map.Entry;

import com.cognizant.model.Row;
import com.cognizant.model.SubTable;
import com.cognizant.model.TablesInPage;
import com.cognizant.model.TextInfo;
import com.cognizant.util.CompareXCols;

/**
 * @author 459090
 * 
 *         HTML writer with position
 *
 */
public class HTMLWriterNew {

	/**
	 * Start tag for html
	 * 
	 * @return
	 */
	private String createBodyTag() {

		return "<html><body>";
	}

	/**
	 * End tag for html
	 * 
	 * @return
	 */
	private String endBodyTag() {

		return "</body></html>";

	}

	/**
	 * Create the html page output
	 * 
	 * @param pdfContent
	 * @return
	 */
	public String createHTML(Map<Integer, Object> pdfContent) {
		StringBuffer htmlContent = new StringBuffer();
		htmlContent.append(createBodyTag());
		for (Entry<Integer, Object> entry : pdfContent.entrySet()) {
			if (entry.getValue() instanceof TablesInPage) {
				// all the tables in page -TablesInPage

				TablesInPage pageContent = (TablesInPage) entry.getValue();
				double height = pageContent.getHeight(), width = pageContent.getWidth();

				// placing a div tag before starting the tables in page
				// with the actual image height and width from the pdf page
				htmlContent.append("<div style='position:relative;height:" + height + "px;width:" + width + "px'>");

				for (int tableNo = 0; tableNo < pageContent.getNoOfTables(); tableNo++) {
					// taking each subtable - table tag
					SubTable table = pageContent.getSubTable(tableNo);
					htmlContent.append("<table>");
					// if (table.getMaxNoCol() == 1) {
					// htmlContent.append("<tr><td>");
					// for (int row = 0; row < table.getnoofrow(); row++) {
					// Row tableRow = table.getrow(row);
					// for (int col = 0; col < tableRow.getsize(); col++) {
					// String content = tableRow.getpoint(col).getText();
					// htmlContent.append(content + "</br>");
					// }
					// }
					// htmlContent.append("</td></tr>");
					// } else {
					for (int row = 0; row < table.getNoOfRows(); row++) {
						// each row in the subtable - tr tag
						Row tableRow = table.getrow(row);
						htmlContent.append("<tr>");
						Collections.sort(tableRow.row, new CompareXCols());
						for (int col = 0; col < tableRow.getSize(); col++) {
							// each col in the row
							// String content =
							// tableRow.getPoint(col).getText();
							// get text content and put in div tag with its
							// position
							// String[] texts=content.split("�");
							// String fontFamily=
							// tableRow.getPoint(col).getFontFamily();
							// if(null!=fontFamily&&fontFamily.length()>0)
							// fontFamily =
							// fontFamily.substring(fontFamily.indexOf("+")+1,
							// fontFamily.length());
							if (!tableRow.getPoint(col).isHasHeading()) {
								htmlContent
										.append("<td style='position:absolute;top:" + tableRow.getPoint(col).getP2().y
												+ "px;left:" + tableRow.getPoint(col).getP1().x + "px;width:"
												+ tableRow.getPoint(col).getWidth() + "px;height:"
												+ tableRow.getPoint(col).getHeight() + "px;'>");// border:
																								// 1px
																								// solid
																								// #888;
								for (TextInfo textInfo : tableRow.getPoint(col).getTextInfoList()) {
									String fontFamily = textInfo.getFontFamily();
									double fontSize = textInfo.getFontSize();
									if (null != fontFamily && fontFamily.length() > 0)
										fontFamily = fontFamily.substring(fontFamily.indexOf("+") + 1,
												fontFamily.length());
									else
										fontFamily = "default";
									if(fontSize==0.0)
										fontSize = 12;
									htmlContent.append("<span style='font-family:" + fontFamily + ";font-size:"
											+ fontSize + "px;'>");
									htmlContent.append(textInfo.getText()+" ");
									htmlContent.append("</span>");//<br/>
								}
							} else {
								htmlContent.append("<td>");
								if (tableRow.getPoint(col).getTextInfoList().size() > 1) {
									htmlContent.append("<span style='position:absolute;top:"
											+ tableRow.getPoint(col).getP2().y + "px;left:"
											+ tableRow.getPoint(col).getP1().x + "px;width:"
											+ tableRow.getPoint(col).getWidth() + "px;height:"
											+ tableRow.getPoint(col).getHeight() + "px;'>");
									for (TextInfo textInfo : tableRow.getPoint(col).getTextInfoList()) {
										String fontFamily = textInfo.getFontFamily();
										double fontSize = textInfo.getFontSize();
										if (null != fontFamily && fontFamily.length() > 0)
											fontFamily = fontFamily.substring(fontFamily.indexOf("+") + 1,
													fontFamily.length());
										else
											fontFamily = "default";
										if(fontSize==0.0)
											fontSize = 12.0;
										
										if (textInfo.isHeading()) {
											String headingType = textInfo.getHeadingType();
											// border:
																									// 1px
																									// solid
																									// #888;
											htmlContent.append("<" + headingType + ">");
											htmlContent.append("<span style='font-family:" + fontFamily + ";font-size:"
													+ fontSize + "px;'>");
											htmlContent.append(textInfo.getText()+" ");
											htmlContent.append("</span>");
											htmlContent.append("</" + headingType + ">");//<br />
											
										} else {
											htmlContent.append("<span style='font-family:" + fontFamily + ";font-size:"
													+ fontSize + "px;'>");
											htmlContent.append(textInfo.getText()+" ");
											htmlContent.append("</span>");//<br />
											
										}
										
									}
									htmlContent.append("</span>");
								} else {
									htmlContent.append("<span style='position:absolute;top:"
											+ tableRow.getPoint(col).getP2().y + "px;left:"
											+ tableRow.getPoint(col).getP1().x + "px;width:"
											+ tableRow.getPoint(col).getWidth() + "px;height:"
											+ tableRow.getPoint(col).getHeight() + "px;'>");
									TextInfo textInfo = tableRow.getPoint(col).getTextInfoList().get(0);
									String fontFamily = textInfo.getFontFamily();
									double fontSize = textInfo.getFontSize();
									if (null != fontFamily && fontFamily.length() > 0)
										fontFamily = fontFamily.substring(fontFamily.indexOf("+") + 1,
												fontFamily.length());
									else
										fontFamily = "default";
									if(fontSize==0.0)
										fontSize = 12.0;
									if (textInfo.isHeading()) {
										String headingType = textInfo.getHeadingType();
										htmlContent.append("<" + headingType + ">");
										htmlContent.append("<span style='font-family:" + fontFamily + ";font-size:"
												+ fontSize + "px;'>");
										htmlContent.append(textInfo.getText()+" ");
										htmlContent.append("</span>");
										htmlContent.append("</" + headingType + ">");//<br/>
										htmlContent.append("</span>");
										
									}
								}
							}
							htmlContent.append("</td>");
						}

						htmlContent.append("</tr>");
						// }
					}
					htmlContent.append("</table>");
					htmlContent.append("</br>");
				}
				// htmlContent.append("<p align='center'>" + entry.getKey() +
				// "</p>");
				htmlContent.append("</div>");
			} else {
				htmlContent.append("<p> No suitable content found</p>");
			}
			// htmlContent.append("<p align='center'>" + entry.getKey() +
			// "</p>");
		}
		htmlContent.append(endBodyTag());
		return htmlContent.toString();
	}
}
