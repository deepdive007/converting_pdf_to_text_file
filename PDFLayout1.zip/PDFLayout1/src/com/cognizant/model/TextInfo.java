package com.cognizant.model;

import java.util.HashMap;
import java.util.Map;

public class TextInfo {
	private String text;
	private String fontFamily;
	private double fontSize;
	private String headingType;
	boolean isHeading;
	//various param like fontsize ratio, wordlength ratio
	Map<String,Double> params;
	
	public TextInfo(){
		text = "";
		fontFamily = "";
		fontSize = 0.0;
		isHeading = false;
		headingType = "";
		params=new HashMap<String,Double>();
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getFontFamily() {
		return fontFamily;
	}

	public void setFontFamily(String fontFamily) {
		this.fontFamily = fontFamily;
	}

	public void setFontSize(double fontSize) {
		this.fontSize = fontSize;
	}

	public double getFontSize() {
		return fontSize;
	}
	
	@Override
	public String toString() {
		return "TextInfo [text=" + text + ", fontFamily=" + fontFamily + ", fontSize=" + fontSize + ", headingType="
				+ headingType + ", isHeading=" + isHeading + ", params=" + params + "]";
	}

	public boolean isHeading() {
		return isHeading;
	}

	public void setHeading(boolean isHeading) {
		this.isHeading = isHeading;
	}

	public Map<String, Double> getParams() {
		return params;
	}

	public void setParams(Map<String, Double> params) {
		this.params = params;
	}

	public void addParams(String name, double value){
		params.put(name, value);
	}

	public String getHeadingType() {
		return headingType;
	}

	public void setHeadingType(String headingType) {
		this.headingType = headingType;
	}
	
}
