//package com.cognizant.output.writer;
//
//import java.util.Collections;
//import java.util.Map;
//import java.util.Map.Entry;
//
//import com.cognizant.model.Row;
//import com.cognizant.model.SubTable;
//import com.cognizant.model.TablesInPage;
//import com.cognizant.util.CompareXCols;
//
//public class HTMLWriterOld {
//
//	private String createBodyTag() {
//
//		return "<html><body>";
//	}
//
//	private String endBodyTag() {
//
//		return "</body></html>";
//
//	}
//
//	public String createHTML(Map<Integer, Object> pdfContent) {
//		StringBuffer htmlContent = new StringBuffer();
//		htmlContent.append(createBodyTag());
//		for (Entry<Integer, Object> entry : pdfContent.entrySet()) {
//			if (entry.getValue() instanceof TablesInPage) {
//				TablesInPage pageContent = (TablesInPage) entry.getValue();
//				for (int tableNo = 0; tableNo < pageContent.getNoOfTables(); tableNo++) {
//					//htmlContent.append("<p> this is table:" + tableNo + "</p>");
//					htmlContent.append("<table border=1>");
//					SubTable table = pageContent.getSubTable(tableNo);			
//					/*if (table.getMaxNoCol() == 1) {
//						htmlContent.append("<tr><td>");
//						for (int row = 0; row < table.getnoofrow(); row++) {
//							Row tableRow = table.getrow(row);						
//							for (int col = 0; col < tableRow.getSize(); col++) {
//								String content = tableRow.getpoint(col).getText();
//								htmlContent.append(content + "</br>");
//							}
//						}
//						htmlContent.append("</td></tr>");
//					} else {*/
//						for (int row = 0; row < table.getNoOfRows(); row++) {
//							htmlContent.append("<tr>");
//							Row tableRow = table.getrow(row);
//							Collections.sort(tableRow.row, new CompareXCols());
//							for (int col = 0; col < tableRow.getSize(); col++) {
//								String content = tableRow.getPoint(col).getText();
//								htmlContent.append("<td>" + content + "</td>");
//							}
//
//							htmlContent.append("</tr>");
//					//	}
//					}
//					htmlContent.append("</table>");
//					htmlContent.append("</br>");
//				}
//
//			} else {
//				htmlContent.append("<p> No suitable content found</p>");
//			}
//			htmlContent.append("<p align='center'>" + entry.getKey() + "</p>");
//		}
//		htmlContent.append(endBodyTag());
//		return htmlContent.toString();
//	}
//}
