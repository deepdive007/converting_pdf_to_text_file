package com.cognizant.util;

import java.util.Comparator;

import org.opencv.core.Point;

import com.cognizant.model.FileTextInfo;

public class CompareFileList implements Comparator<FileTextInfo>{

	@Override
	public int compare(FileTextInfo o1, FileTextInfo o2) {
		Point p4o1=	new Point(o1.getX1(),o1.getY1());
		Point p4o2=	new Point(o2.getX1(),o2.getY1());

		// TODO Auto-generated method stub
		return 0;
	}

}
