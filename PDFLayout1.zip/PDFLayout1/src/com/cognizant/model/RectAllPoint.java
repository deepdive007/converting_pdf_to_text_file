package com.cognizant.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.opencv.core.Point;

public class RectAllPoint {
	private Point p1;
	private Point p2;
	private Point p3;
	private Point p4;
//	private String text;
	private int width;
	private int height;
	boolean textPlaced = false;
//	private String fontFamily;
//	private String fontSize;
	List<TextInfo> textInfoList;
	Map<String,Double> params;
	boolean hasHeading;
	
	public RectAllPoint(Point P1, Point P2, Point P3, Point P4) {
		this.p1 = P1;
		this.p2 = P2;
		this.p3 = P3;
		this.p4 = P4;
//		this.text = "";
		textInfoList = new ArrayList<TextInfo>();
		params = new HashMap<String, Double>();
		hasHeading = false;
	}

	public Point getP1() {
		return p1;
	}

	public void setP1(Point p1) {
		this.p1 = p1;
	}

	public Point getP2() {
		return p2;
	}

	public void setP2(Point p2) {
		this.p2 = p2;
	}

	public Point getP3() {
		return p3;
	}

	public void setP3(Point p3) {
		this.p3 = p3;
	}

	public Point getP4() {
		return p4;
	}

	public void setP4(Point p4) {
		this.p4 = p4;
	}

//	public String getText() {
//		return text;
//	}
//
//	public void setText(String text) {
//		this.text = text;
//	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}
//
//	public String getFontFamily() {
//		return fontFamily;
//	}
//
//	public void setFontFamily(String fontFamily) {
//		this.fontFamily = fontFamily;
//	}
//
//	public String getFontSize() {
//		return fontSize;
//	}
//
//	public void setFontSize(String fontSize) {
//		this.fontSize = fontSize;
//	}

//	@Override
//	public String toString() {
//		return "RectAllPoint [p1=" + p1 + ", p2=" + p2 + ", p3=" + p3 + ", p4=" + p4 + ", text=" + text + ", width="
//				+ width + ", height=" + height + ", fontFamily=" + fontFamily + ", fontSize=" + fontSize + "]";
//	}

	public List<TextInfo> getTextInfoList() {
		return textInfoList;
	}

	public void setTextInfoList(List<TextInfo> textInfoList) {
		this.textInfoList = textInfoList;
	}

	public void addTextInfo(TextInfo text){
		textInfoList.add(text);
	}

	public void addTextInfoList(List<TextInfo> textInfoList){
		this.textInfoList.addAll(textInfoList);
	}

	@Override
	public String toString() {
		return "RectAllPoint [p1=" + p1 + ", p2=" + p2 + ", p3=" + p3 + ", p4=" + p4 + ", width=" + width + ", height="
				+ height + ", textInfoList=" + textInfoList + "]";
	}

	public Map<String, Double> getParams() {
		return params;
	}

	public void setParams(Map<String, Double> params) {
		this.params = params;
	}

	public boolean isHasHeading() {
		return hasHeading;
	}

	public void setHasHeading(boolean hasHeading) {
		this.hasHeading = hasHeading;
	}
	
	public void addParams(String name, double value){
		params.put(name, value);
	}
	public boolean isTextPlaced() {
		return textPlaced;
	}

	public void setTextPlaced(boolean textPlaced) {
		this.textPlaced = textPlaced;
	}
}
