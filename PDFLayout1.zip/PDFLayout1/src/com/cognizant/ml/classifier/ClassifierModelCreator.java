package com.cognizant.ml.classifier;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;

import ca.uwo.csd.ai.nlp.kernel.LinearKernel;
import ca.uwo.csd.ai.nlp.mallet.libsvm.SVMClassifier;
import ca.uwo.csd.ai.nlp.mallet.libsvm.SVMClassifierTrainer;
import cc.mallet.classify.ClassifierTrainer;
import cc.mallet.pipe.Csv2FeatureVector;
import cc.mallet.pipe.Pipe;
import cc.mallet.pipe.SerialPipes;
import cc.mallet.pipe.Target2Label;
import cc.mallet.pipe.iterator.CsvIterator;
import cc.mallet.types.Instance;
import cc.mallet.types.InstanceList;
import cc.mallet.types.Labeling;

public class ClassifierModelCreator {
	public static void main(String[] args) {
		String directory = "D:/Divya/OCRParser/pdflatest/testing/file/";
		String trainingFileName = "trainingdata",validationFileName="validationdata";
		ArrayList<Pipe> pipes = new ArrayList<Pipe>();
		pipes.add(new Target2Label());
		pipes.add(new Csv2FeatureVector());
		SerialPipes pipe = new SerialPipes(pipes);
		InstanceList trainingData = new InstanceList(pipe);
		try {
			trainingData.addThruPipe(
					new CsvIterator(new FileReader(directory + trainingFileName + ".txt"), "(.*)\t(.*)", 1, 2, -1));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ClassifierTrainer trainer = new SVMClassifierTrainer(new LinearKernel());
		SVMClassifier classifier = (SVMClassifier) trainer.train(trainingData);
//		 DecisionTreeTrainer trainer = new DecisionTreeTrainer();
//		 Classifier classifier = trainer.train(trainingData);
//		ClassifierTrainer trainer = new NaiveBayesTrainer();
//		NaiveBayes classifier = (NaiveBayes) trainer.train(trainingData);
//		ClassifierTrainer trainer = new MaxEntTrainer();
//		MaxEnt classifier = (MaxEnt) trainer.train(trainingData);
		ObjectOutputStream s;
		try {
			s = new ObjectOutputStream(new FileOutputStream(directory + "Classification_SVM.model"));
			s.writeObject(classifier);
			s.flush();
			s.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		InstanceList validationData = new InstanceList(classifier.getInstancePipe());
		try {
			validationData.addThruPipe(
					new CsvIterator(new FileReader(directory + validationFileName + ".txt"), "(.*)\t(.*)", 1, 2, -1));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

		Iterator<Instance> iterator = validationData.iterator();
		Labeling labeling = null;
		while (iterator.hasNext()) {
			Instance instance = (Instance) iterator.next();
			labeling = classifier.classify(instance).getLabeling();
		}
		System.out.println("Accuracy: " + classifier.getAccuracy(validationData));
		System.out.println("============================================================");
		Iterator<String> labelIterator = labeling.getLabelAlphabet().iterator();
		while (labelIterator.hasNext()) {
			String label = labelIterator.next();
			System.out.println("Category: " + label);
			System.out.println("F-Score: " + classifier.getF1(validationData, label));
			System.out.println("Precision: " + classifier.getPrecision(validationData, label));
			System.out.println("Recall: " + classifier.getRecall(validationData, label));
			System.out.println("============================================================");
		}
	}
}
