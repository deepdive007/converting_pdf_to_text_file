package com.cognizant.util;

public class Constants {

	public static final String NEXT_PAGE = "----NEXTPAGE----"; 
	public static final String PYTHON = "python";
	// for converting to image
	public static final double MAXVAL = 255;
	public static final int BLOCK_SIZE = 5;
	public static final double C = 20;
	public static final String FONTSIZE_RATIO_PREV = "fontsizeratioprev";
	public static final String FONTSIZE_RATIO_NEXT = "fontsizerationext";
	public static final String WORDLEN_RATIO_PREV = "wordlenratioprev";
	public static final String WORDLEN_RATIO_NEXT = "wordlenrationext";
	public static final String CAPITAL_TEXT = "capsinfo";
	public static final String BOLD_TEXT = "boldtext";
	public static final String DEFAULT_CLASS = "none";
}
