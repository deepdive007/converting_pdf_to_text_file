package com.cognizant.ml.classifier;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.util.Iterator;

import com.cognizant.util.ConfigFileLoader;
import com.cognizant.util.Constants;
import com.cognizant.util.UtilityManager;

import ca.uwo.csd.ai.nlp.mallet.libsvm.SVMClassifier;
import cc.mallet.classify.Classifier;
import cc.mallet.pipe.iterator.CsvIterator;
import cc.mallet.types.Instance;
import cc.mallet.types.InstanceList;
import cc.mallet.types.Labeling;

public class Classification {
	public String extractCategory(String lineFeatures, String testingDataFile) throws IOException {
		// TODO Auto-generated method stub
		//InputStream inputStream = Classification.class.getClassLoader().getResourceAsStream("./Classification_SVM");
		InputStream inputStream = new FileInputStream(new File(ConfigFileLoader.getModelFilePath()));
		UtilityManager um = new UtilityManager();
		Classifier classifier = null;
		String testData = lineFeatures + "\t"+Constants.DEFAULT_CLASS; 
//		System.out.println("testdata:"+testData);
		um.prepareTestingDataFile(testData, testingDataFile);
		StringBuilder cls = null;
		Object o1 = null;
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(inputStream);
			o1 = ois.readObject();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			ois.close();
		}
		classifier = (SVMClassifier) o1;
		if (null != classifier) {
			InstanceList testingInstanceList = new InstanceList(classifier.getInstancePipe());
			FileReader reader = new FileReader(testingDataFile);
			testingInstanceList.addThruPipe(new CsvIterator(reader, "(.*)\t(.*)", 1, 2, -1));
			Iterator<Instance> iter = testingInstanceList.iterator();
			StringBuilder output = null;

			while (iter.hasNext()) {
				Instance instance = (Instance) iter.next();
				Labeling labeling = classifier.classify(instance).getLabeling();
				output = new StringBuilder();
				cls = new StringBuilder();
				output.append(instance.getName());
				double maxProb = 0;
				maxProb = labeling.valueAtLocation(0);
				for (int location = 0; location < labeling.numLocations(); location++) {

					if (maxProb < labeling.valueAtLocation(location))
						maxProb = labeling.valueAtLocation(location);
				}
				for (int location = 0; location < labeling.numLocations(); location++) {
					if (labeling.valueAtLocation(location) == maxProb) {
						cls.append(labeling.labelAtLocation(location));

						output.append("\t" + labeling.labelAtLocation(location));
						output.append("\t" + labeling.valueAtLocation(location));
					}
				}
			}
			reader.close();
			inputStream.close();
		}
//		System.out.println("value:"+cls.toString());
		return cls.toString();

	}
	public static void main(String[] args) {
		Classification classi = new Classification();
		try {
			System.out.println(classi.extractCategory("fontsizerationext=1.0, wordlenratioprev=0.0, wordlenrationext=0.9333333333333333, capsinfo=1.0, boldtext=1.0, fontsizeratioprev=0.0", "D:\\Divya\\OCRParser\\pdflatest\\testing\\file\\classtext.txt"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
