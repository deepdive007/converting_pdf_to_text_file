//package com.cognizant.process;
//
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Collections;
//import java.util.HashMap;
//import java.util.LinkedList;
//import java.util.List;
//import java.util.Map;
//
//import org.opencv.core.Core;
//import org.opencv.core.Mat;
//import org.opencv.core.MatOfPoint;
//import org.opencv.core.Point;
//import org.opencv.core.Rect;
//import org.opencv.core.Scalar;
//import org.opencv.core.Size;
//import org.opencv.imgcodecs.Imgcodecs;
//import org.opencv.imgproc.Imgproc;
//
//import com.cognizant.model.FileTextInfo;
//import com.cognizant.model.PDFPage;
//import com.cognizant.model.RectAllPoint;
//import com.cognizant.model.Row;
//import com.cognizant.model.SubTable;
//import com.cognizant.model.TablesInPage;
//import com.cognizant.output.writer.HTMLWriterOld;
//import com.cognizant.util.CompareFileList;
//import com.cognizant.util.CompareRect;
//import com.cognizant.util.ConvertPDFToImages;
//import com.cognizant.util.ExecuteCommand;
//import com.cognizant.util.ReadFile;
//
//public class PDFLayoutProcessOldVersion {
//	static int adaptiveMethod = Imgproc.ADAPTIVE_THRESH_MEAN_C;
//	final static double maxval = 255;
//	static int blockSize = 5;
//	final static double C = 20;
//
//	public static TablesInPage convolute(String sourceDir, String destinationDir, String pdfFileName,
//			String imgFileName, List<FileTextInfo> listTextInfo, int pageNo) {
//
//		Mat source = Imgcodecs.imread(destinationDir + imgFileName + ".jpg");
//		Mat binary = source.clone();
//		Mat destination = new Mat();
//
//		// convert to gray scale
//		Imgproc.cvtColor(binary, binary, Imgproc.COLOR_RGB2GRAY);
//		/** black and white image */
//		Imgproc.adaptiveThreshold(binary, destination, maxval, adaptiveMethod, Imgproc.THRESH_BINARY, blockSize, C);
//		Imgcodecs.imwrite(destinationDir + imgFileName + "binary.jpg", destination);
//		/** Blurring the words alone */
//		Mat erosionMat = destination.clone();
//		int kerWidth = 4, kerHeight = 1;
//		Mat kernel = Imgproc.getStructuringElement(0, new Size(kerWidth, kerHeight));
//		int iterations = 7;
//		Imgproc.erode(erosionMat, erosionMat, kernel, new Point(-1, -1), iterations);
//		Imgcodecs.imwrite(destinationDir + imgFileName + "erode.jpg", erosionMat);
//
//		/** Put bounding box around it */
//		Mat bounding = erosionMat.clone();
//		Mat hierarchy = new Mat();
//		List<MatOfPoint> contours = new LinkedList<>();
//		Imgproc.findContours(bounding, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
//
//		Imgproc.cvtColor(bounding, bounding, Imgproc.COLOR_GRAY2BGR);
//		List<Rect> listRect = new ArrayList<Rect>();
//		for (MatOfPoint pt : contours) {
//			if (Imgproc.contourArea(pt) > 25) {
//				Rect rect = Imgproc.boundingRect(pt);
//				if (rect.height > 8) {
//					Imgproc.rectangle(bounding, rect.br(), rect.tl(), new Scalar(0, 0, 255));
//
//					listRect.add(rect);
//				}
//			}
//		}
//		Imgcodecs.imwrite(destinationDir + imgFileName + "erodewordsboxed.jpg", bounding);
//		System.out.println("Number of Rectangles found::" + listRect.size());
//
//		Collections.reverse(listRect);
//
//		Size imgSize = source.size();
//		System.out.println("imgSize:" + imgSize);
//		FileTextInfo pageSize = listTextInfo.remove(0);
//		System.out.println("pdfPageSize:" + pageSize);
//		TablesInPage pageContent = reCreateLayout(imgSize, pageSize, listRect, listTextInfo, source.type(),
//				destinationDir, pdfFileName, pageNo);
//		return pageContent;
//	}
//
//	// recreating using the bounding box and the text
//	private static TablesInPage reCreateLayout(Size imgSize, FileTextInfo pageSize, List<Rect> listRect,
//			List<FileTextInfo> listTextInfo, int type, String destinationDir, String fileName, int pageNo) {
//		double xScale = pageSize.getX2() / imgSize.width;
//		double yScale = pageSize.getY2() / imgSize.height;
//
//		Mat recreateImg = new Mat(imgSize, type);
//		Imgproc.cvtColor(recreateImg, recreateImg, Imgproc.COLOR_RGB2GRAY);
//		Imgproc.adaptiveThreshold(recreateImg, recreateImg, maxval, adaptiveMethod, Imgproc.THRESH_BINARY, blockSize,
//				C);
//		Imgproc.cvtColor(recreateImg, recreateImg, Imgproc.COLOR_GRAY2BGR);
//
//		// for (Rect re : listRect) {
//		// Imgproc.rectangle(recreateImg, re.br(), re.tl(), new Scalar(0, 0,
//		// 255));
//		// }
//		System.out.println("size of file is " + listTextInfo.size());
//		for (FileTextInfo text : listTextInfo) {
//			Imgproc.putText(recreateImg, text.getText(),
//					new Point(text.getX1() / xScale, imgSize.height - (text.getY1() / yScale)), 1, 0.85,
//					new Scalar(0, 0, 0));
//		}
//		// vikrant changes in code
//		List<FileTextInfo> listTextInfocopy = listTextInfo;
//		// sort listtextinfo based on p4.y cord
//		Collections.sort(listTextInfocopy, new CompareFileList());
//		// trying to link text with co-ordinate......
//		// Mat imageforfilecord = new Mat();
//		// for checking file co-ordinate rectangle
//		// imageforfilecord = recreateImg.clone();
//		Mat imageforfilecorresponding = new Mat();
//		// for checking image co-ordinate rectangle
//		imageforfilecorresponding = recreateImg.clone();
//		Mat imageforimagecorresponding = new Mat();
//		imageforimagecorresponding = recreateImg.clone();
//		// FOR CHECKING CORRECT TEXT IN RECTPOINT
//		Mat Rectpointtext = new Mat();
//		Rectpointtext = recreateImg.clone();
//		// list of rectangle from file
//		List<RectAllPoint> rectpointoffile = new ArrayList<RectAllPoint>();
//		// to remove the effect of eroding and dilating
//		double apsilonx = 6.0;
//		double apsilony = 5.0;
//		// creating scaled co-ordinate of rectangle from file
//		for (FileTextInfo text : listTextInfo) {
//			Point p4 = new Point(text.getX1() / xScale - apsilonx, imgSize.height - (text.getY1() / yScale));
//			Point p2 = new Point(text.getX2() / xScale + apsilonx, imgSize.height - (text.getY2() / yScale) + apsilony);
//			Point p3 = new Point(p2.x, p4.y);
//			Point p1 = new Point(p4.x, p2.y);
//			RectAllPoint rc = new RectAllPoint(p1, p2, p3, p4);
//			rc.setText(text.getText());
//			rectpointoffile.add(rc);
//
//		}
//		// sorting the rectangle co-ordinate from file based p4 point
//		Collections.sort(rectpointoffile, new CompareRect());
//		// for(int i=0;i<rectpointoffile.size() ;i++)
//		// {
//		// printing points.....
//		// System.out.println("index= "+i+" "+rectpointoffile.get(i).getP1()+"
//		// "+rectpointoffile.get(i).getP2()+" "+rectpointoffile.get(i).getP3()+"
//		// "+rectpointoffile.get(i).getP4());
//
//		// }
//
//		// for(int i=0;i<rectpointoffile.size() ;i++)
//		// {
//		// printing the specific rectangle from file co-ordinate
//		// int i=71;
//		// Imgproc.rectangle(imageforfilecord, rectpointoffile.get(i).getP2(),
//		// rectpointoffile.get(i).getP4(), new Scalar(0, 0, 255));
//		// System.out.println("index for file= "+i+"
//		// "+rectpointoffile.get(i).getP1()+" "+rectpointoffile.get(i).getP2()+"
//		// "+rectpointoffile.get(i).getP3()+" "+rectpointoffile.get(i).getP4());
//		// }
//		// Imgcodecs.imwrite(destinationDir + fileName + "imageforfilecord.jpg",
//		// imageforfilecord);
//		System.out.println("initial no of rectangles " + listRect.size());
//		// creating rectangle from image co-ordinate
//		List<RectAllPoint> rectpoint = new ArrayList<RectAllPoint>();
//		for (int i = 0; i < listRect.size(); i++) {
//			// create 4 point for rectangles...
//			Rect rect = listRect.get(i);
//			Point p1 = rect.tl();
//			Point p2 = rect.br();
//			int width = rect.width;
//			int height = rect.height;
//			Point P1 = new Point(p1.x, p1.y);
//			Point P2 = new Point(p1.x + width, p1.y);
//			Point P3 = new Point(p2.x, p2.y);
//			Point P4 = new Point(p1.x, p1.y + height);
//			RectAllPoint rc = new RectAllPoint(P1, P2, P3, P4);
//			rectpoint.add(rc);
//
//		}
//		// sort the rectangles of image co-ordinate based on y cordinate of p4
//		// point....
//		Collections.sort(rectpoint, new CompareRect());
//		// printing points.....
//		// for(int i=0;i<rectpoint.size() ;i++)
//		// {
//		// System.out.println("index= "+i+" "+rectpoint.get(i).getP1()+"
//		// "+rectpoint.get(i).getP2()+" "+rectpoint.get(i).getP3()+"
//		// "+rectpoint.get(i).getP4());
//
//		// }
//		System.out.println("-p---------------------------------------");
//		// printing total no of rectangles found from image co-ordinate
//		System.out.println(" total no of rectangles found " + rectpoint.size());
//		// printing specific rectangle from image co-ordinate
//		// Mat imageforimagecord = new Mat();
//		// imageforimagecord = recreateImg.clone();
//		// for(int i=0;i<rectpoint.size() ;i++)
//		// {int i=77;
//		// System.out.println("index= "+i+" "+rectpoint.get(i).getP1()+"
//		// "+rectpoint.get(i).getP2()+" "+rectpoint.get(i).getP3()+"
//		// "+rectpoint.get(i).getP4());
//		/// System.out.println(rectpoint.get(i).getP3());
//		// Imgproc.rectangle(imageforimagecord, rectpoint.get(i).getP2(),
//		// rectpoint.get(i).getP4(), new Scalar(0, 0, 255));
//		// }
//		// Imgcodecs.imwrite(destinationDir + fileName +
//		// "imageforimagecord.jpg", imageforimagecord);
//
//		// trying to get corresponding cordinate of rectangle of image to file
//		List<List<Integer>> correspondingrect = new ArrayList<List<Integer>>();
//		// containing the corressponding index of rectangle from file to image
//		System.out.println("size of filetext " + listTextInfo.size());
//		System.out.println("size of rectpointfile " + rectpointoffile.size());
//		// trying to map rectangles got from file to rectangles got from image
//		for (int i = 0; i < rectpointoffile.size(); i++) {
//			List<Integer> ls = new ArrayList<Integer>();
//			// printing points.....
//			for (int j = 0; j < rectpoint.size(); j++) { // System.out.println("i=");
//				if (Math.abs(rectpoint.get(j).getP4().x - rectpointoffile.get(i).getP4().x) < 10
//						&& Math.abs(rectpoint.get(j).getP4().y - rectpointoffile.get(i).getP4().y) < 10) {
//					// System.out.println("index= "+j+"
//					// "+rectpoint.get(j).getP1()+" "+rectpoint.get(j).getP2()+"
//					// "+rectpoint.get(j).getP3()+" "+rectpoint.get(j).getP4());
//					// System.out.println("index= "+i+"
//					// "+rectpointoffile.get(i).getP1()+"
//					// "+rectpointoffile.get(i).getP2()+"
//					// "+rectpointoffile.get(i).getP3()+"
//					// "+rectpointoffile.get(i).getP4());
//
//					// System.out.println("yes");
//					ls.add(i);
//					ls.add(j);
//					// System.out.println(listTextInfo.get(j).getText());
//					// System.out.println(rectpointoffile.get(i).getText());
//					correspondingrect.add(ls);
//
//				}
//			}
//			// if(correspondingrect.isEmpty()==false)
//		}
//
//		// trying to set the text got from file rectangle to corresponding
//		// rectangle in image....
//		for (int i = 0; i < correspondingrect.size(); i++) {// int i=0;
//			int filecord = correspondingrect.get(i).get(0);
//			// System.out.println("TEXT IS
//			// "+rectpointoffile.get(filecord).getText());
//			int imagecord = correspondingrect.get(i).get(1);
//			Imgproc.rectangle(imageforfilecorresponding, rectpointoffile.get(filecord).getP2(),
//					rectpointoffile.get(filecord).getP4(), new Scalar(0, 0, 255));
//			Imgproc.rectangle(imageforimagecorresponding, rectpoint.get(imagecord).getP2(),
//					rectpoint.get(imagecord).getP4(), new Scalar(0, 0, 255));
//			Imgcodecs.imwrite(destinationDir + fileName + "imageforfilecorresponding.jpg", imageforfilecorresponding);
//			Imgcodecs.imwrite(destinationDir + fileName + "imageforimagecorresponding.jpg", imageforimagecorresponding);
//
//			rectpoint.get(imagecord).setText(rectpointoffile.get(filecord).getText());
//
//		}
//		// printing the corresponding rect no
//		// for(int i=0;i<correspondingrect.size();i++)
//		// {
//		// int filecord=correspondingrect.get(i).get(0);
//		// int imagecord=correspondingrect.get(i).get(1);
//		// System.out.println("at index "+i+" the file rect no "+ filecord+"
//		// have corresponding rect no in image is "+imagecord);
//		// }
//
//		System.out.println("size of corressponding rec is " + correspondingrect.size());
//
//		// TRYING TO PRINT RECTPOINT RECTANGLES AND TEXT
//
//		for (int j = 0; j < rectpoint.size(); j++) {
//			Imgproc.rectangle(Rectpointtext, rectpoint.get(j).getP2(), rectpoint.get(j).getP4(), new Scalar(0, 0, 255));
//			Imgcodecs.imwrite(destinationDir + fileName + "rectpointtext.jpg", Rectpointtext);
//			// System.out.println("rectv text is "+rectpoint.get(j).getText());
//		}
//		// finding the table point to make out some rectangle into one......
//		// list of no of total rows in a page containing information how many
//		// rectangle a row contained...
//		List<Integer> noofrows = new ArrayList<Integer>();
//		SubTable allpagerow = new SubTable();
//
//		int j;
//		// trying to find the multicoln....start
//		for (j = 0; j < rectpoint.size() - 1;) {
//
//			int k;
//			k = j + 1;
//			while (k < rectpoint.size() && (Math.abs(rectpoint.get(j).getP1().y - rectpoint.get(k).getP1().y) < 5
//					|| Math.abs(rectpoint.get(j).getP4().y - rectpoint.get(k).getP4().y) < 5)) {
//				k++;
//			}
//			noofrows.add(k - j);
//
//			// with object oriented
//			int putinrect = j;
//			Row row = new Row();
//			while (putinrect != k) {
//
//				row.add(rectpoint.get(putinrect));
//				putinrect = putinrect + 1;
//			}
//
//			// subtablerow.add(rowlist);
//			// object oreint
//			allpagerow.add(row);
//			j = k;
//		}
//
//		// for last rectangle
//		if (j + 1 == rectpoint.size()) {
//			noofrows.add(1);
//			Row row = new Row();
//			row.add(rectpoint.get(j));
//			allpagerow.add(row);
//		}
//		// trying to find the multicoln....end
//
//		// int totalcount=0;
//		// printing no of col in each row..........
//		// for(int m=0;m<noofrows.size();m++) {
//		// totalcount+=noofrows.get(m);
//		// System.out.println("content of array index " +m +"is "+
//		// noofrows.get(m));
//		// }
//		// System.out.println(" total no of rectangles found "+totalcount);
//		// System.out.println(" total no of rows found in a page found
//		// "+allpagerow.getnoofrow());
//
//		// System.out.println("size of table rect"+tablepoint.size());
//		// trying to get subTable with in page
//		// List<Subtable > tablesInPage = new ArrayList <Subtable>();
//
//		TablesInPage tablesInPage = new TablesInPage();
//
//		boolean IGNORED_FLAG = false;
//		// trying to get subtables within a page......
//		for (int m = 0; m < noofrows.size();) {
//			// multicolumns rows...............
//
//			// System.out.println("this is a multicolumn row of containing "+
//			// noofrows.get(m)+ " with index of m is "+m+" columns ");
//
//			// System.out.println("in loop");
//			SubTable subTable = new SubTable(); // list that contain subTable
//			if (IGNORED_FLAG == true && subTable.isEmpty() && m < noofrows.size()) {
//				// System.out.println("in if loop");
//				System.out.println("index here is " + m);
//
//				subTable.add(allpagerow.getrow(m - 1));
//				System.out.println("row  " + (m - 1) + " is inserted into table no " + tablesInPage.getNoOfTables()
//						+ " with " + allpagerow.getrow(m - 1).getSize() + " column..");
//				subTable.add(allpagerow.getrow(m));
//				System.out.println("row  " + m + " is inserted into table no " + tablesInPage.getNoOfTables() + " with "
//						+ allpagerow.getrow(m).getSize() + " column..");
//				m++;
//				IGNORED_FLAG = false;
//			}
//			// TABLE STRUCTURE IS INITIATED.....
//			else if (subTable.isEmpty() && m < noofrows.size()) {
//				// System.out.println("in else if loop");
//				subTable.add(allpagerow.getrow(m));
//				System.out.println("row  " + m + " is inserted into table no " + tablesInPage.getNoOfTables() + " with "
//						+ allpagerow.getrow(m).getSize() + " column..");
//
//				m++;
//			}
//			// if(IGNORED_FLAG==true){}
//			if (m >= 1 && m < noofrows.size() && (noofrows.get(m) != noofrows.get(m - 1))) {
//				IGNORED_FLAG = true;
//				m++;
//			}
//
//			while (((IGNORED_FLAG == false && m >= 1 && m < noofrows.size() && noofrows.get(m) == noofrows.get(m - 1)))
//					|| ((m >= 2 && m < noofrows.size() && (noofrows.get(m) == noofrows.get(m - 2)
//							|| (m > 3 && noofrows.get(m - 1) == noofrows.get(m - 3))))))// extending
//																						// same
//																						// table
//			{
//				// System.out.println("in while loop");
//				if (IGNORED_FLAG == true) {
//					subTable.add(allpagerow.getrow(m - 1));
//					System.out.println("row  " + (m - 1) + " is inserted into table no " + tablesInPage.getNoOfTables()
//							+ " with " + allpagerow.getrow(m - 1).getSize() + " column..");
//				}
//				System.out.println("row  " + m + " is inserted into table no " + tablesInPage.getNoOfTables() + " with "
//						+ allpagerow.getrow(m).getSize() + " column..");
//				subTable.add(allpagerow.getrow(m));
//				IGNORED_FLAG = false;
//				m++;
//				if (m >= 1 && m < noofrows.size() && (noofrows.get(m) != noofrows.get(m - 1))) {
//					IGNORED_FLAG = true;
//					m++;
//				}
//			}
//
//			tablesInPage.add(subTable);
//		}
//		System.out.println("total no of table in page is " + tablesInPage.getNoOfTables());
//		// totalno of subtables size is....extracted
//		for (int m = 0; m < tablesInPage.getNoOfTables(); m++) {
//			System.out.println("size of each table is " + tablesInPage.getSubTable(m).getNoOfRows());
//		}
//		// printing box of subTable got.....
//		// for(int noOfTables=0;noOfTables<tablesInPage.size();noOfTables++)
//		// {int noOfTables=3;
//		// for(int
//		// noOfRow=0;noOfRow<tablesInPage.getsubtable(noOfTables).getnoofrow();noOfRow++)
//		// {
//		// for(int
//		// noOfCol=0;noOfCol<tablesInPage.getsubtable(noOfTables).getrow(noOfRow).getsize();noOfCol++)
//		// {
//		// Imgproc.rectangle(recreateImg,
//		// tablesInPage.getsubtable(noOfTables).getrow(noOfRow).getpoint(noOfCol).getP2(),
//		// tablesInPage.getsubtable(noOfTables).getrow(noOfRow).getpoint(noOfCol).getP4(),
//		// new Scalar(0, 0, 255));
//		//
//		// }
//		// }
//		// }
//		// to check weather getting right text or not for each rectangle.....
//		for (int noOfTables = 0; noOfTables < tablesInPage.getNoOfTables(); noOfTables++) {
//			// int noOfTables=1;
//			for (int noOfRow = 0; noOfRow < tablesInPage.getSubTable(noOfTables).getNoOfRows(); noOfRow++) {
//				// int noOfRow=1;
//				for (int noOfCol = 0; noOfCol < tablesInPage.getSubTable(noOfTables).getrow(noOfRow)
//						.getSize(); noOfCol++) {
//					// int noOfCol=0;
//					Imgproc.rectangle(recreateImg,
//							tablesInPage.getSubTable(noOfTables).getrow(noOfRow).getPoint(noOfCol).getP2(),
//							tablesInPage.getSubTable(noOfTables).getrow(noOfRow).getPoint(noOfCol).getP4(),
//							new Scalar(0, 0, 255));
//					System.out.println("corresponding text is "
//							+ tablesInPage.getSubTable(noOfTables).getrow(noOfRow).getPoint(noOfCol).getText());
//				}
//			}
//		}
//
//		Imgcodecs.imwrite(destinationDir + fileName + "recreated.jpg", recreateImg);
//		return tablesInPage;
//	}
//
//	public static void main(String[] args) {
//		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
//		String sourceDir = "D:/Divya/OCRParser/pdflatest/";
//		// String pdfFileName = "page2";
//		String pdfFileName = "pdf_doc";
//		ConvertPDFToImages pdftoimg = new ConvertPDFToImages();
//		int noPages = pdftoimg.pdfToImage(sourceDir, pdfFileName);
//		System.out.println("Number of pages in PDF:" + noPages);
//		if (noPages > 0) {
//			Map<Integer, Object> pdfContent = new HashMap<Integer, Object>();
//			String destinationDir = sourceDir + pdfFileName + "/";
//			/** get coordinates of text */
//			ExecuteCommand cmd = new ExecuteCommand();
//			try {
//				// invoking python code
//				cmd.execute(sourceDir, pdfFileName, destinationDir);
//			} catch (IOException | InterruptedException e) {
//				e.printStackTrace();
//			}
//			// reading from the coordinates file
//			String cordFile = destinationDir + "cordsfuncnew.txt";
//			File file = new File(cordFile);
//			if (file.exists()) {
//				ReadFile rf = new ReadFile();
//				List<PDFPage> pageTextList = rf.readFile(cordFile);
//				System.out.println("PageList:");
//				System.out.println(pageTextList);
//				for (int page = 1; page <= noPages; page++) {
//					List<FileTextInfo> listTextInfo = pageTextList.get(page - 1).getPageTextList();
//					String imgFileName = pdfFileName + "_" + page;
//					// whole page in tables and subtables format
//					TablesInPage pageContent = convolute(sourceDir, destinationDir, pdfFileName, imgFileName,
//							listTextInfo, page);
//					pdfContent.put(page, pageContent);
//				}
//				String htmlContent = createHtml(pdfContent);
//
//				try {
//					File outputFile = new File(destinationDir + pdfFileName + ".html");
//					BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile));
//					bw.write(htmlContent);
//					bw.close();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			} else {
//				System.out.println("Cords file not found. Please Check to proceed and rerun");
//			}
//		} else {
//			System.out.println("There were no pages found in the file. Please check and rerun");
//		}
//
//	}
//
//	private static String createHtml(Map<Integer, Object> pdfContent) {
//		HTMLWriterOld htmlWriter = new HTMLWriterOld();
//		String content = htmlWriter.createHTML(pdfContent);
//		return content;
//	}
//
//}
