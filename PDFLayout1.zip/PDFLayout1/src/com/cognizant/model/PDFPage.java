package com.cognizant.model;

import java.util.ArrayList;
import java.util.List;

public class PDFPage {

	private int pageNo = 0;
	private List<FileTextInfo> pageTextList = new ArrayList<>();

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public List<FileTextInfo> getPageTextList() {
		return pageTextList;
	}

	public void setPageTextList(List<FileTextInfo> pageTextList) {
		this.pageTextList = pageTextList;
	}

	@Override
	public String toString() {
		return "PDFPage [pageNo=" + pageNo + ", pageTextList=" + pageTextList.size() + "]";
	}
}
