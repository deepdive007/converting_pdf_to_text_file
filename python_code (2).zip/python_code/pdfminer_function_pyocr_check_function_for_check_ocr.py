import pdfminer_function_pyocr
from PIL import Image ,ImageEnhance,ImageFilter
import pytesseract
import csv
import cv2
from pytesseract import pytesseract as pt
import os
import sys

def define_image(pdffile):
	#print("ready to ssave image")
	pdffile=pdffile[3:]    # remember to remove directory name from front
	#print("file name",pdffile)
	
	full_path, toc=pdfminer_function_pyocr.get_pages(pdffile)

	nooffileexicutes=1;
	i=0;
	return full_path
	#=='2_Im1.jpg'
	#.endswith(".jpg")
	# for	 filename in os.listdir(full_path) :
		 # print("filename",filename)
		 # if filename.endswith(".jpg")==True: 
			 # print("vikrant")
		
