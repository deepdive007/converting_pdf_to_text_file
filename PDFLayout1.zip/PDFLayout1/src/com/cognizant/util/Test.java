package com.cognizant.util;

public class Test {
public static void main(String[] args) {
	double result = (double)43/(double)52;
	System.out.println(result);
}
}
