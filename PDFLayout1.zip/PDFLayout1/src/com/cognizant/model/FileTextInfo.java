package com.cognizant.model;

public class FileTextInfo implements Comparable<FileTextInfo> {

	private String coordinates;
	private String text;
	private double x1 = 0.0;
	private double y1 = 0.0;
	private double x2 = 0.0;
	private double y2 = 0.0;
	private String fontFamily;
	private double fontSize = 0.0;
	
	public String getCoordinates() {
		return coordinates;
	}

	public void setCoordinates(String coordinates) {
		this.coordinates = coordinates;
		getXY(coordinates);
	}

	private void getXY(String coordinates) {
		String sub = coordinates.substring(1, coordinates.length() - 1);
		String[] cords = sub.split(",");
		setX1(Double.valueOf(cords[0]));
		setY1(Double.valueOf(cords[1]));
		setX2(Double.valueOf(cords[2]));
		setY2(Double.valueOf(cords[3]));
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public double getX1() {
		return x1;
	}

	public void setX1(double x1) {
		this.x1 = x1;
	}

	public double getY1() {
		return y1;
	}

	public void setY1(double y1) {
		this.y1 = y1;
	}

	public double getX2() {
		return x2;
	}

	public void setX2(double x2) {
		this.x2 = x2;
	}

	public double getY2() {
		return y2;
	}

	public void setY2(double y2) {
		this.y2 = y2;
	}

	public String getFontFamily() {
		return fontFamily;
	}

	public void setFontFamily(String fontFamily) {
		this.fontFamily = fontFamily;
	}

	public double getFontSize() {
		return fontSize;
	}

	public void setFontSize(double fontSize) {
		this.fontSize = fontSize;
	}

	@Override
	public String toString() {
		return "FileTextInfo [coordinates=" + coordinates + ", text=" + text + ", x1=" + x1 + ", y1=" + y1 + ", x2="
				+ x2 + ", y2=" + y2 + ", fontFamily=" + fontFamily + ", fontSize=" + fontSize + "]";
	}

	@Override
	public int compareTo(FileTextInfo ft) {
		return (int) (this.y1 - ft.y1);
	}

}
