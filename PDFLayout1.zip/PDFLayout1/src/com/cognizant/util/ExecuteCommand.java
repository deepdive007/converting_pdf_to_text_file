package com.cognizant.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class ExecuteCommand {

	/**
	 * Execute the python code to parse the pdf doc using pdfminer
	 * 
	 * @param fileDir
	 * @param fileName
	 * @param destDir
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void execute(String fileDir, String fileName, String destDir) throws IOException, InterruptedException {
		
//		String str = Constants.PYTHON+" " + ConfigFileLoader.getPythonCodeFilePath() +" \"" + fileDir
//				+ fileName + ".pdf\" \"" + destDir+"\"";
		String str = Constants.PYTHON+" " + ConfigFileLoader.getPythonCodeFilePath() +" \"" + fileDir
				+ fileName + ".pdf\" \"" + destDir+"\" "+destDir+"\"";
		System.out.println("Cmd:"+str);
		
		Process process = Runtime.getRuntime().exec(str);
		
		int status = process.waitFor();
		
		if (status == 0 && process.exitValue() == 0) {
			System.out.println("Successfully invoked");
			InputStream stream = process.getInputStream();
			BufferedReader rd = new BufferedReader(new InputStreamReader(stream));
			String line = "";
			while ((line = rd.readLine()) != null) {
				System.out.println(line);
			}
		} else {
			System.out.println("Failed to invoke");
			InputStream stream = process.getErrorStream();
			BufferedReader rd = new BufferedReader(new InputStreamReader(stream));
			String line = "";
			while ((line = rd.readLine()) != null) {
				System.out.println(line);
			}
		}
		process.destroy();
	}
}
