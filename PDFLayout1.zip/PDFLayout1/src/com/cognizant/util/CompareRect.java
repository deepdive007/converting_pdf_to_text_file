package com.cognizant.util;

import java.util.Comparator;

import com.cognizant.model.RectAllPoint;


public class CompareRect implements Comparator<RectAllPoint>{
		
		@Override
		public int compare(RectAllPoint o1, RectAllPoint o2) {
			//compare y of top-left corner
			return  (int) (o1.getP1().y- o2.getP1().y);
		}
}
