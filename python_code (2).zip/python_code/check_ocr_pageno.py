from pdfminer.pdfpage import PDFPage
from pdfminer.pdfparser import PDFParser
from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer.converter import PDFPageAggregator
from pdfminer.layout import LAParams, LTTextBox, LTTextLine,LTImage, LTFigure,LTChar
from pdfminer.pdfdocument import PDFDocument,PDFNoOutlines
import sys,os
from pdfminer.pdfinterp import resolve1
from io import StringIO
#from pytesseract import pytesseract as pt
import csv
#from IPython.display import Image
import cv2
import numpy as np
import sys
import os
from binascii import b2a_hex
#################
import pdfminer_function_pyocr_check_function_for_check_ocr
import pyocr1_check_function_for_check_ocr
###############
whole_cord_text=[]
media=[]
def ocrpart(lt_obj,cordinates_text,path,pageno,image_folder,image_cordinate):
		if isinstance(lt_obj,LTImage) or isinstance(lt_obj,LTFigure):
			#print("instance of figure")
			#print("image is generating......")
			
			###############to save the image
			#full_path=pdfminer_function_pyocr_check_function_for_check_ocr.define_image(path)# generate all image instantly
			#path=path[3:]
			#print("image will be saved in ",image_folder)
			saved_file = save_image(lt_obj, pageno, image_folder)
	
			
			#print("image is generated and saved as "+saved_file+ "in"+image_folder)
			
			# ############################ image procesing starts.....
			cordinates_text=pyocr1_check_function_for_check_ocr.processing_image(saved_file,image_folder,pageno,cordinates_text,image_cordinate)
			
			# print("full path is=",full_path)
			# print("image contained at path",os.listdir(full_path))
			# print("image processing starts.....")
			# imageList =os.listdir(full_path)
			# for	filename in imageList :
				# print("filename",filename)
				# if filename.endswith(".jpg")==True: 
					# print("vikrant")
					# pyocr1_check_function_for_check_ocr.processing_image(filename,full_path)
			# # ############################
			# # #print(pt.image_to_string(lt_obj,cord))
			return cordinates_text

def parse_layout(layout,cordinates_text,path,pageno,image_folder): #to parse the layout of each pdf page
	#print("we r in layout")
	"""Function to recursively parse the layout tree."""
	for lt_obj in layout:
		if isinstance(lt_obj, LTTextBox):
			for o in lt_obj._objs:
				if isinstance(o, LTTextLine):
					l=[]
					l.append(str(o.bbox))
					#l.append(str(o.get_text()))
					for c in o._objs:
						if isinstance(c, LTChar):
							l.append(str(c.fontname))
							l.append(str(c.size))
							break
					l.append(str(o.get_text()))
					#cordinates_text.append(l)
					if str(o.get_text())!="":
						cordinates_text.append(l)
					text=o.get_text()
					#print(str(o.bbox))
					#print(str(o.get_text()))
					#print("=====\n")
		elif isinstance(lt_obj, LTImage): #or isinstance(lt_obj, LTFigure):
			#print("object of ltimage")
		#	print(str(lt_obj.bbox))
			#l=[]
			#l.append(str(lt_obj.bbox))
			image_cordinate=lt_obj.bbox
			#l.append("we have image here\n")
			#cordinates_text.append(l)
			
			
			if str(lt_obj.bbox)!='':
				#print("we have image here\n")
				#print(str(lt_obj.bbox))
		#		print("i m here")
				cordinates_text=ocrpart(lt_obj,cordinates_text,path,pageno,image_folder,image_cordinate)
				#s=open("ope.jpg", "wb")
				#s.write(lt_obj)
			
			
		elif isinstance(lt_obj, LTFigure):
			cordinates_text=parse_layout(lt_obj,cordinates_text,path,pageno,image_folder)  # Recursive
	return cordinates_text
			
			
def pagecord(fp,path,image_folder):
	

	#return page size and did processing on each pdf page
	parser = PDFParser(fp)
	doc = PDFDocument(parser)
	rsrcmgr = PDFResourceManager()
	laparams = LAParams()
	device = PDFPageAggregator(rsrcmgr, laparams=laparams)
	interpreter = PDFPageInterpreter(rsrcmgr, device)
	#print(resolve1(doc.catalog['Pages'])['Count'])
	#print(type(PDFDocument.get_pages()))
	#for pageNumber, page in enumerate(PDFDocument.get_pages()):
	for pageno, page in enumerate(PDFPage.create_pages(doc)):
		#if pageno==1:
		#	break;
		cordinates_text=[]
	#	print(type(PDFPage.create_pages(doc)))
		#print(page.mediabox)
		#print(page.cropbox)
		str1=str(page.mediabox)
		media.append(str1)
		interpreter.process_page(page)
		layout = device.get_result()
		cordinates_text=parse_layout(layout,cordinates_text,path,pageno+1,image_folder)
		whole_cord_text.append(cordinates_text)
	return media


def findtextandcord(path,image_folder): #find the page size and cordinates and corresponding text from pdf file
	fp = open(path, 'rb')
	pagesize=pagecord(fp,path,image_folder) 
	#print(len(cordinates_text))
	return  pagesize,whole_cord_text;	

	
	
	##################################################trying to make flexible 
def with_pdf (pdf_doc, fn, pdf_pwd, *args):
	print("in with")
	"""Open the pdf document, and apply the function, returning the results"""
	result = None
	try:
		# open the pdf file
		fp = open(pdf_doc, 'rb')
		# create a parser object associated with the file object
		parser = PDFParser(fp)
		# create a PDFDocument object that stores the document structure
		doc = PDFDocument(parser)
		# connect the parser and document objects
		parser.set_document(doc)
		# supply the password for initialization
		#doc.initialize(pdf_pwd)
		
		if doc.is_extractable:
			# apply the function and return the result
			result = fn(doc, *args)
			
		# close the pdf file
		fp.close()
	except IOError:
		# the file doesn't exist or similar problem
		pass
	return result
	
	
###
### Table of Contents
###

def _parse_toc (doc):
    """With an open PDFDocument object, get the table of contents (toc) data
    [this is a higher-order function to be passed to with_pdf()]"""
    toc = []
    try:
        outlines = doc.get_outlines()
        for (level,title,dest,a,se) in outlines:
            toc.append( (level, title) )
    except PDFNoOutlines:
        pass
    return toc

def get_toc (pdf_doc, pdf_pwd=''):
    """Return the table of contents (toc), if any, for this pdf file"""
    return with_pdf(pdf_doc, _parse_toc, pdf_pwd)


###
### Extracting Images
###

def write_file (folder, filename, filedata, flags='w'):
    """Write the file data to the folder and filename combination
    (flags: 'w' for write text, 'wb' for write binary, use 'a' instead of 'w' for append)"""
    result = False
    if os.path.isdir(folder):
        try:
            file_obj = open(os.path.join(folder, filename), flags)
            file_obj.write(filedata)
            file_obj.close()
            result = True
        except IOError:
            pass
    return result

def determine_image_type (stream_first_4_bytes):
	#print("in determine _image_type")
	"""Find out the image file type based on the magic number comparison of the first 4 (or 2) bytes"""
	file_type = None
	bytes_as_hex = b2a_hex(stream_first_4_bytes)
	#print("bytes_as_hex",bytes_as_hex)
	if bytes_as_hex.startswith(b'ffd8'):
	#	print("image type jpg")
		file_type = '.jpg'
	elif bytes_as_hex == '89504e47':
		#print("image type png")
		file_type = '.png'
	elif bytes_as_hex == '47494638':
		#print("image type gif")
		file_type = '.gif'
	elif bytes_as_hex.startswith(b'424d'):
		#print("image type bmp")
		file_type = '.bmp'
	#print("file type=",file_type)
	return file_type	
	
	
	
def save_image (lt_image, page_number, images_folder):
	#print("in save image")
	"""Try to save the image data from this LTImage object, and return the file name, if successful"""
	result = None
	if lt_image.stream:
		file_stream = lt_image.stream.get_rawdata()
	#	print("in save image1")
		#print("file stream",file_stream)
		if file_stream:
			file_ext = determine_image_type(file_stream[0:4])
	#		print("in save image2")
			if file_ext:
				file_name = ''.join([str(page_number), '_', lt_image.name, file_ext])
	#			print("in save image3")
				if write_file(images_folder, file_name, file_stream, flags='wb'):
					result = file_name
	#				print("in save image4")
	#print("image name",result)
	#return result
        
	if result!=None:
		return result
	########### trying to save plane image instead of unsupported imageas...
	img = np.ones([792, 612, 3], dtype=np.uint8)
	img[:,:,:]=255
	cv2.imwrite(images_folder+"image.jpg", img)
	print("unsupporatble image replaced with plane image")
	return "image.jpg";


###
### Extracting Text
###

	
def to_bytestring (s, enc='utf-8'):
    """Convert the given unicode string to a bytestring, using the standard encoding,
    unless it's already a bytestring"""
    if s:
        if isinstance(s, str):
            return s
        else:
            return s.encode(enc)
	
def update_page_text_hash (h, lt_obj, pct=0.2):
    """Use the bbox x0,x1 values within pct% to produce lists of associated text within the hash"""

    x0 = lt_obj.bbox[0]
    x1 = lt_obj.bbox[2]

    key_found = False
    for k, v in h.items():
        hash_x0 = k[0]
        if x0 >= (hash_x0 * (1.0-pct)) and (hash_x0 * (1.0+pct)) >= x0:
            hash_x1 = k[1]
            if x1 >= (hash_x1 * (1.0-pct)) and (hash_x1 * (1.0+pct)) >= x1:
                # the text inside this LT* object was positioned at the same
                # width as a prior series of text, so it belongs together
                key_found = True
                v.append(to_bytestring(lt_obj.get_text()))
                h[k] = v
    if not key_found:
        # the text, based on width, is a new series,
        # so it gets its own series (entry in the hash)
        h[(x0,x1)] = [to_bytestring(lt_obj.get_text())]

    return h	
	
	

def parse_lt_objs (lt_objs, page_number, images_folder, text_content=None):
	#print("in parse_lt_obj")
	"""Iterate through the list of LT* objects and capture the text or image data contained in each"""
	if text_content is None:
		text_content = []
	page_text = {} # k=(x0, x1) of the bbox, v=list of text strings within that bbox width (physical column)
	for lt_obj in lt_objs:
		if isinstance(lt_obj, LTTextBox) or isinstance(lt_obj, LTTextLine):
			# text, so arrange is logically based on its column width
			page_text = update_page_text_hash(page_text, lt_obj)
		elif isinstance(lt_obj, LTImage):
			print("instance of LTImage")
			# an image, so save it to the designated folder, and note its place in the text
			saved_file = save_image(lt_obj, page_number, images_folder)
			if saved_file:
				# use html style <img /> tag to mark the position of the image within the text
				text_content.append('<img src="'+os.path.join(images_folder, saved_file)+'" />')
			else:
				print (sys.stderr, "error saving image on page", page_number, lt_obj.__repr__)
		elif isinstance(lt_obj, LTFigure):
			# LTFigure objects are containers for other LT* objects, so recurse through the children
			text_content.append(parse_lt_objs(lt_obj, page_number, images_folder, text_content))

	for k, v in sorted([(key,value) for (key,value) in page_text.items()]):
		# sort the page_text hash by the keys (x0,x1 values of the bbox),
		# which produces a top-down, left-to-right sequence of related columns
		text_content.append(''.join(v))

	return '\n'.join(text_content)

	
def _parse_pages (doc, images_folder):
	"""With an open PDFDocument object, get the pages and parse each one
	[this is a higher-order function to be passed to with_pdf()]"""
	rsrcmgr = PDFResourceManager()
	laparams = LAParams()
	device = PDFPageAggregator(rsrcmgr, laparams=laparams)
	interpreter = PDFPageInterpreter(rsrcmgr, device)
	#print("saini")
	text_content = []
	for i, page in enumerate(PDFPage.create_pages(doc)):
		print("page no",i)
		interpreter.process_page(page)
		# receive the LTPage object for this page
		layout = device.get_result()
		# layout is an LTPage object which may contain child objects like LTTextBox, LTFigure, LTImage, etc.
		text_content.append(parse_lt_objs(layout, (i+1), images_folder))
	# return text_content
	
	
def get_pages (pdf_doc, pdf_pwd='', images_folder='d:\imagepro'):
	print("vikrant")
	"""Process each of the pages in this pdf file and return a list of strings representing the text found in each page"""
	#print("vikrant")
	full_path=os.path.join(images_folder,pdf_doc[:-4])
	#print(os.getcwd())
	#print(full_path)
	# create 'dynamic' dir, if it does not exist
	if not os.path.exists(full_path):
		os.makedirs(full_path)
		#images_folder=os.path.join(images_folder,pdf_doc)
	full_path=os.path.join(full_path,pdf_doc)
	if not os.path.exists(full_path):
		os.makedirs(full_path)
	images_folder=full_path
	#print(images_folder)
	return full_path, with_pdf(pdf_doc, _parse_pages, pdf_pwd, *tuple([images_folder]))

	######################################################
def main():
	path=sys.argv[1]  # taking pdf path as input from cmd
	#print(path)
	image_folder=sys.argv[2];
	pagesize,whole_cord_text=findtextandcord(path,image_folder)
	#print(len(whole_cord_text))
	#print(type(whole_cord_text))
	Outputpath=sys.argv[3]
	outputpath = Outputpath + "cordsfuncnew.txt"
	print("process doen")
	# img = np.ones([792, 612, 3], dtype=np.uint8)
	# img[:,:,:]=255
	# cv2.imwrite("imageforwhole_page.jpg", img)
	# img = cv2.imread("imageforwhole_page.jpg")
	#print("len of media box pagesize&&&&&&&&&&&&&",len(pagesize))
	#print("len of media box  at a 0 pagesize&&&&&&&&&&&&&",pagesize[0])
	#print("len of media box  at a 1 pagesize&&&&&&&&&&&&&",pagesize[1])
	
	with open(outputpath, "w",encoding='utf8') as fileq: # file that have output for page size and text and their co-ordinates for each pdf page
		print("in cordsfuncnew")
		m=0;	
		i=0;
		for page in whole_cord_text:
			paGesize=pagesize[m]
			paGesize=paGesize.strip()
			pageSize=paGesize[1:len(paGesize)-1].split(", ")
			#print("pagesizesplitted------------------",pageSize,type(pageSize))
			PageSize=[int(float(j)) for j in pageSize]
			#print("pagesize------------------",PageSize,type(PageSize[2]))
			#img = np.ones([792, 612, 3], dtype=np.uint8)
			#img[:,:,:]=255
			#cv2.imwrite("imageforwhole_page.jpg", img)
			#img = cv2.imread("imageforwhole_page.jpg")
			i+=1;
			fileq.write(pagesize[m])
			fileq.write("\n\n\n")
			fileq.write("pagesize\n\n")
			m=m+1;
			for textlist in page:
				#for textcord in textlist:
				#	fileq.write(textcord)
				#	fileq.write("yahoo")
				#	fileq.write("\n")
				fileq.write(textlist[0])
				fileq.write("\n")
				fileq.write(textlist[1])
				fileq.write("\n")
				fileq.write(textlist[2])
				fileq.write("\n")
				fileq.write(textlist[3])
				fileq.write("\n")
				############################# create an image for whole page
				#cordString=textlist[0].strip()
				#only_cordinate=cordString[1:len(cordString)-1].split(", ")
				
				#int_cordinate=[int(float(i)) for i in only_cordinate]
				#print("len(int_cordinate)********",len(int_cordinate))
				#print("int_cordinate+++++++++",int_cordinate)
				#if len(int_cordinate)==4:
					#img = cv2.rectangle(img,(int_cordinate[0],PageSize[3]-int_cordinate[1]),(int_cordinate[2],PageSize[3]-int_cordinate[3]),(255,0,0),2)
				###############################
			fileq.write("----NEXTPAGE----\n\n")
		#	cv2.imwrite(str(i)+"checkpartial_full_page.jpg",img)
		print("i am done")
if __name__=="__main__":
	main()
	



			
			
