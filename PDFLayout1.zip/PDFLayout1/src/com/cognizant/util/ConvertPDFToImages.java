package com.cognizant.util;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;

import javax.imageio.ImageIO;

@SuppressWarnings("unchecked")
public class ConvertPDFToImages {

	public int pdfToImage(String sourceDir, String filename) {
		// to get the total number of pages n images it has to create
		int pageNumber = 1;
		try {
			String destinationDir = sourceDir + filename + "/";
			File sourceFile = new File(sourceDir + filename + ".pdf");
			File destinationFile = new File(destinationDir);
			if (!destinationFile.exists()) {
				destinationFile.mkdir();
				System.out.println("Folder Created -> " + destinationFile.getAbsolutePath());
			}
			if (sourceFile.exists()) {
				System.out.println("Images copied to Folder: " + destinationFile.getName());
				// load whole document
				PDDocument document = PDDocument.load(sourceDir + filename + ".pdf");
				// get all the pages as a list
				List<PDPage> list = document.getDocumentCatalog().getAllPages();
				System.out.println("Total files to be converted -> " + list.size());
				String fileName = sourceFile.getName().replace(".pdf", "");
				for (PDPage page : list) {
					// convert each page to image
					BufferedImage image = page.convertToImage();
					File outputfile = new File(destinationDir + fileName + "_" + pageNumber + ".jpg");
					System.out.println("Image Created -> " + outputfile.getName());
					// write the image to the destination
					ImageIO.write(image, "jpg", outputfile);
					pageNumber++;
				}
				--pageNumber;
				document.close();
				System.out.println("Converted Images are saved at -> " + destinationFile.getAbsolutePath());
			} else {
				// file not found
				System.err.println(sourceFile.getName() + " File not exists");
				pageNumber = 0;
			}

		} catch (Exception e) {
			//any error occurs during conversion
			System.err.println("Error in converting to image for file.");
			e.printStackTrace();
		}
		return pageNumber;
	}

}
