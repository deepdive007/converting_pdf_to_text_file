package com.cognizant.util;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

public class ConfigFileLoader {
	private static String pythonCodeFilePath;
	private static String pythonOutPutFile;
	private static String sourceDir;
	private static String modelFilePath;
	static {
		Properties prop = new Properties();
		try {
			System.out
					.println("Trying to read --> " + "." + File.separator + "" + File.separator + "config.properties");
			prop.load(ConfigFileLoader.class.getClassLoader().getResourceAsStream("./config.properties"));
		} catch (IOException e) {
			System.err.println("Oops the following location didnt work --> " + "." + File.separator + ""
					+ File.separator + "config.properties");
			e.printStackTrace();
		}
		if (prop != null && prop.size() != 0) {
			pythonCodeFilePath = prop.getProperty("pythonCodeFilePath");
			pythonOutPutFile = prop.getProperty("pythonOutPutFile");
			sourceDir = prop.getProperty("sourceDir");
			modelFilePath = prop.getProperty("modelFilePath");
			System.out.println("Properties loaded!");
		}
	}

	public static String getPythonCodeFilePath() {
		return pythonCodeFilePath;
	}

	public static String getPythonOutPutFile() {
		return pythonOutPutFile;
	}

	public static String getSourceDir() {
		return sourceDir;
	}

	public static String getModelFilePath() {
		return modelFilePath;
	}

}
