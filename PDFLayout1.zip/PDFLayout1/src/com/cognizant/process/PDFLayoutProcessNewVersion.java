package com.cognizant.process;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import com.cognizant.ml.classifier.Classification;
import com.cognizant.model.FileTextInfo;
import com.cognizant.model.PDFPage;
import com.cognizant.model.RectAllPoint;
import com.cognizant.model.Row;
import com.cognizant.model.SubTable;
import com.cognizant.model.TablesInPage;
import com.cognizant.model.TextInfo;
import com.cognizant.output.writer.HTMLWriterNew;
import com.cognizant.util.CompareFileList;
import com.cognizant.util.CompareRect;
import com.cognizant.util.CompareXCols;
import com.cognizant.util.ConfigFileLoader;
import com.cognizant.util.Constants;
import com.cognizant.util.ConvertPDFToImages;
import com.cognizant.util.ExecuteCommand;
import com.cognizant.util.ReadFile;
import com.cognizant.util.UtilityManager;

public class PDFLayoutProcessNewVersion {

	public static TablesInPage processLayout(String sourceDir, String destinationDir, String pdfFileName,
			String imgFileName, List<FileTextInfo> listTextInfo, int pageNo) {

		Mat source = Imgcodecs.imread(destinationDir + imgFileName + ".jpg");
		Mat binary = source.clone();
		Mat destination = new Mat();
		Mat binary1 = source.clone();// to check missing result
		// convert to gray scale
		destination = setBasicImageFeatures(binary, destination);
		// uncomment to test the image mat obtained
		// Imgcodecs.imwrite(destinationDir + imgFileName + "binary.jpg",
		// destination);

		Mat image_h = Mat.zeros(source.size(), destination.type());
		Mat image_v = Mat.zeros(source.size(), destination.type());
		Mat output = destination.clone();
		Mat output_result = new Mat();
		// removing horizontal lines
		Mat kernel_h = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(20, 1));
		Imgproc.morphologyEx(output, image_h, Imgproc.MORPH_OPEN, kernel_h);
		Core.subtract(output, image_h, output_result);
		// uncomment to test the image mat obtained
		// Imgcodecs.imwrite(destinationDir + imgFileName + "kernel_h.jpg",
		// output);
		// Imgcodecs.imwrite(destinationDir + imgFileName + "kernel_h_sub.jpg",
		// output_result);

		// removing vertical lines
		Mat kernel_v = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(1, 20));
		Imgproc.morphologyEx(output_result, image_v, Imgproc.MORPH_OPEN, kernel_v);
		Mat output_result2 = new Mat();
		Core.subtract(output_result, image_v, output_result2);
		Mat dst = new Mat();
		Core.bitwise_not(output_result2, dst);
		// uncomment to test the image mat obtained
		// Imgcodecs.imwrite(destinationDir + imgFileName + "kernel_v_sub.jpg",
		// dst);

		// changes end
		/** Blurring the words alone */
		Mat erosionMat = dst.clone();
		int kerWidth = 4, kerHeight = 1;
		Mat kernel = Imgproc.getStructuringElement(0, new Size(kerWidth, kerHeight));
		int iterations = 7;
		Imgproc.erode(erosionMat, erosionMat, kernel, new Point(-1, -1), iterations);
		// uncomment to test the image mat obtained
		// Imgcodecs.imwrite(destinationDir + imgFileName + "erode.jpg",
		// erosionMat);

		/** Put bounding box around it */
		Mat bounding = erosionMat.clone();
		Mat hierarchy = new Mat();
		Mat toDraw1 = new Mat(source.size(), source.type());
		toDraw1 = setBasicImageFeatures(toDraw1, toDraw1);
		List<MatOfPoint> contours = new LinkedList<>();
		/**
		 * RETR_LIST - retrieves all contours found CHAIN_APPROX_SIMPLE - end
		 * points only
		 */
		Imgproc.findContours(bounding, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
		// uncomment if printing to image n to convert from greyscale to color
		Imgproc.cvtColor(bounding, bounding, Imgproc.COLOR_GRAY2BGR);
		List<Rect> listRect = new ArrayList<Rect>();
		for (MatOfPoint pt : contours) {
			// minimum are of the rectangle for it to be text
			if (Imgproc.contourArea(pt) > 25) {
				Rect rect = Imgproc.boundingRect(pt);
				// removes horizontal lines
				if (rect.height > 8) {
					Imgproc.rectangle(toDraw1, rect.br(), rect.tl(), new Scalar(0, 0, 255));

					listRect.add(rect);
				}
			}
		}
		// uncomment to test the image mat obtained
		// Imgcodecs.imwrite(destinationDir + imgFileName +
		// "erodewordsboxed.jpg", toDraw1);
		// System.out.println("Number of Rectangles found::" + listRect.size());

		// Mat to get the outer rectangles.
		Mat erosionMat1 = destination.clone();
		int kerWidth1 = 6, kerHeight1 = 3;
		// int kerWidth1 = 4, kerHeight1 = 2;
		Mat kernel1 = Imgproc.getStructuringElement(0, new Size(kerWidth1, kerHeight1));
		// int iterations1 = 4;
		int iterations1 = 5;
		Imgproc.erode(erosionMat1, erosionMat1, kernel1, new Point(-1, -1), iterations1);
		// uncomment to test the image mat obtained
		// Imgcodecs.imwrite(destinationDir + imgFileName + "erode1.jpg",
		// erosionMat1);

		/** Put bounding box around it */
		Mat bounding1 = erosionMat1.clone();
		Mat hierarchy1 = new Mat();
		List<MatOfPoint> contours1 = new LinkedList<>();
		Imgproc.findContours(bounding1, contours1, hierarchy1, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE);
		Mat toDraw = new Mat(source.size(), source.type());
		toDraw = setBasicImageFeatures(toDraw, toDraw);
		Imgproc.cvtColor(toDraw, toDraw, Imgproc.COLOR_GRAY2BGR);
		List<Rect> listRect1 = new ArrayList<Rect>();
		for (MatOfPoint pt : contours1) {
			if (Imgproc.contourArea(pt) > 50) {
				Rect rect = Imgproc.boundingRect(pt);
				if (rect.height > 8 /* && rect.area() > 7500 */ ) {
					Imgproc.rectangle(toDraw, rect.br(), rect.tl(), new Scalar(0, 0, 255));
					listRect1.add(rect);
				}
			}
		}
		// uncomment to test the image mat obtained
		// Imgcodecs.imwrite(destinationDir + imgFileName +
		// "erodewordsboxed1.jpg", toDraw);
		// System.out.println("Number of Rectangles found::" +
		// listRect1.size());

		// outer rectangles
		List<RectAllPoint> outerRectList = getAllpoints(listRect1);
		// sorting based on p4 y
		Collections.sort(outerRectList, new CompareRect());

		// if there are any rectangles inside any of the outer rectangles remove
		// them
		List<RectAllPoint> toRemoveFromOuterList = new ArrayList<RectAllPoint>();
		for (int i = 1; i < outerRectList.size() - 1; i++) {
			RectAllPoint r1 = outerRectList.get(i);
			for (int j = i + 1; j < outerRectList.size(); j++) {
				RectAllPoint r2 = outerRectList.get(j);
				if (((r1.getP1().x <= r2.getP1().x) && (r1.getP1().y <= r2.getP1().y))
						&& ((r1.getP3().x >= r2.getP3().x) && (r1.getP3().y >= r2.getP3().y))) {
					toRemoveFromOuterList.add(r2);
				}
			}
		}
		outerRectList.removeAll(toRemoveFromOuterList);
		// uncomment to test the image mat obtained
		// Mat testDraw1 = new Mat(source.size(), source.type());
		// testDraw1 = setBasicImageFeatures(testDraw1, testDraw1);
		// for (RectAllPoint rect : outerRectList) {
		// Imgproc.rectangle(testDraw1, rect.getP2(), rect.getP4(), new
		// Scalar(0, 0, 255));
		// }
		// Imgcodecs.imwrite(destinationDir + imgFileName + "onlyouter.jpg",
		// testDraw1);
		// inner rectangles
		List<RectAllPoint> innerRectList = getAllpoints(listRect);
		// sorting based on p4 y
		Collections.sort(innerRectList, new CompareRect());

		// create subtable by finding the inner rectangles of outer rectangle
		TablesInPage listGroupedRects = new TablesInPage();
		for (int i = 1; i < outerRectList.size(); i++) {
			// int i = 18;
			RectAllPoint rect = outerRectList.get(i);
			// calling method to find the inner rectangles
			SubTable grouped = getInnerRects(rect, innerRectList);
			listGroupedRects.add(grouped);
		}

		// to print outer + inner rects
//		System.out.println("Source details:" + source.size() + ";" + source.type());
//		Mat testDraw = new Mat(source.size(), source.type());
//		testDraw = setBasicImageFeatures(testDraw, testDraw);
		// uncomment if printing to image n to convert from greyscale to color
//		Imgproc.cvtColor(testDraw, testDraw, Imgproc.COLOR_GRAY2BGR);
//		System.out.println("Listgrouped rects info:");
//		System.out.println("No of table:" + listGroupedRects.getNoOfTables());
//		for (int i = 0; i < listGroupedRects.getNoOfTables(); i++) {
//			// int i=5;
//			SubTable groupRects = listGroupedRects.getSubTable(i);
//			System.out.println("No of rows in table " + i + " : " + groupRects.getNoOfRows());
//			for (int j = 0; j < groupRects.getNoOfRows(); j++) {
//				Row row = groupRects.getrow(j);
//				System.out.println("No of cols in row " + j + " : " + row.getSize());
//				for (int k = 0; k < row.getSize(); k++) {
//					RectAllPoint rect = row.getPoint(k);
//					Imgproc.rectangle(testDraw, rect.getP2(), rect.getP4(), new Scalar(0, 0, 255));
//				}
//			}
//		}
		// uncomment to test the image mat obtained
		// System.out.println("==========END============");
		//	Imgcodecs.imwrite(destinationDir + imgFileName + "erodewordsboxedTest1.jpg", testDraw);

		Collections.reverse(listRect);

		Size imgSize = source.size();
		// removing first element ad first element is always page size
		FileTextInfo pageSize = listTextInfo.remove(0);
		System.out.println("pdfPageSize:" + pageSize);
		TablesInPage pageContent = reCreateLayout(imgSize, pageSize, listGroupedRects, listTextInfo, source.type(),
				destinationDir, pdfFileName, pageNo,binary1);
		return pageContent;
	}

	/**
	 * group the outer n its corresponding inner rects
	 * 
	 * @param rect
	 *            - outer boundary
	 * @param innerRectList
	 * @return
	 */
	private static SubTable getInnerRects(RectAllPoint rect, List<RectAllPoint> innerRectList) {
		SubTable subTable = new SubTable();
		List<RectAllPoint> groupRect = new ArrayList<RectAllPoint>();
		// groupRect.add(rect);
		for (RectAllPoint innerRect : innerRectList) {
			// condition to check that the innerRect is inside rect or not
			if (((rect.getP1().x <= innerRect.getP1().x) && (rect.getP1().y <= innerRect.getP1().y))
					&& ((rect.getP3().x >= innerRect.getP3().x) && (rect.getP3().y >= innerRect.getP3().y))) {
				// if yes add to the list
				groupRect.add(innerRect);

			}
		}
		// testing
//		Mat testDraw = new Mat(new Size(1224, 1584), 16);
//		testDraw = setBasicImageFeatures(testDraw, testDraw);
//		Imgproc.rectangle(testDraw, rect.getP2(), rect.getP4(), new Scalar(0, 0, 255));
//		for (RectAllPoint rect1 : groupRect) {
//			Imgproc.rectangle(testDraw, rect1.getP2(), rect1.getP4(), new Scalar(0, 0, 255));
//		}
//		Imgcodecs.imwrite("D:\\Divya\\OCRParser\\pdflatest\\" + "page3\\" + "grouped.jpg", testDraw);
		//
		/** To check for paragraph */
		// in case inner rectangles found
		if (groupRect.size() > 1) {
			int count = 0;
			for (int i = 0; i < groupRect.size(); i++) {
				int outerWidth = rect.getWidth();
				int innerWidth = groupRect.get(i).getWidth();
				if (outerWidth == innerWidth) {
					// width of inner and outer rectangle same increase count
					count++;
				}
				// else if(Math.abs(outerWidth-innerWidth)<=15){
				else if (outerWidth > innerWidth) {
					// if (innerWidth + 15 >= outerWidth)
					if (outerWidth - innerWidth <= 40)
						// width of inner rect is almost same as outer rect
						count++;
				} else if (innerWidth > outerWidth) {
					// // inner rect might be bit larger than outer rect
					count++;
				} else if ((rect.getP1().x == groupRect.get(i).getP1().x)
						|| ((Math.abs(rect.getP1().x - groupRect.get(i).getP1().x)) <= 10)) {
					// check this condition
					count++;
				}
			}

			// in case the number of inner rects which has width
			// same or almost same as the outer rect and that
			// count is more than the half the number of inner rects found
			// means it is a paragraph, so remove the inner rects and include
			// only outer rect.
			if (count > 0 && (count >= (groupRect.size() / 2))) {
				// add only outer rectangle
				groupRect.clear();
				groupRect.add(rect);
			}
			// if condition fails then it is a paragraph keep it as it is
		}
		subTable = createTableStructure(groupRect);
		return subTable;
	}

	/**
	 * Identifying the table structure - rows & cols
	 * 
	 * @param groupRect
	 * @return
	 */
	private static SubTable createTableStructure(List<RectAllPoint> groupRect) {
		SubTable subTable = new SubTable();
		List<Integer> noofrows = new ArrayList<Integer>();
		int j;
		////////////////////////////////////////////////////checking issues in overlapping part.....
		//System.out.println("making table is start from here..........................................\n ");
		//for (j = 0; j < groupRect.size() - 1;j++)
		//{
		//	System.out.println("cord of "+ j+ "th rectangle is "+groupRect.get(j).getP1()+" "+groupRect.get(j).getP2()+" "+groupRect.get(j).getP3()+" "+groupRect.get(j).getP4());
	//	}
		
		// trying to find the multicoln....start
		for (j = 0; j < groupRect.size() - 1;) {

			int k;
			k = j + 1;
			////////////////////////////////////// for finding overlapping
			////////////////////////////////////// between rectangle
			double overlappingThreshold = 60; // v
			//System.out.println("cordinate value of j is=" + j + " and " + groupRect.get(j).getP1() + " "
			//		+ groupRect.get(j).getP2() + " " + groupRect.get(j).getP3() + " " + groupRect.get(j).getP4());// v
		//	System.out.println("cordinate value of k is=" + k + " and " + groupRect.get(k).getP1() + " "
		//			+ groupRect.get(k).getP2() + " " + groupRect.get(k).getP3() + " " + groupRect.get(k).getP4());// v
			boolean cond = true;// v
			cond = ((groupRect.get(j).getP4().y < groupRect.get(k).getP1().y
					|| groupRect.get(j).getP1().y > groupRect.get(k).getP4().y)); // v
			//System.out.println("cond=" + cond);// v
			double overlappedvaluefunc = 0;// v
			if (!cond)// v
			{// v
				// v
				overlappedvaluefunc = overlap(groupRect.get(j), groupRect.get(k));// v
			//	System.out.println("overlappedfuncvalue= " + overlappedvaluefunc);// v
				////// (Math.abs(rectpoint.get(j).getP1().y -
				////// rectpoint.get(k).getP1().y) < 5||
				////// Math.abs(rectpoint.get(j).getP4().y -
				////// rectpoint.get(k).getP4().y) < 5)//v
			} // v
			while (k < groupRect.size() && !cond && overlappedvaluefunc >= overlappingThreshold) {// v
				k++;// v
		//		System.out.println("k=" + k + " and size of list is " + groupRect.size());// v
				if (k < groupRect.size())// v
				{/////// to create effect in while loop//v
					// v
					/////////////////////// //v
					//System.out.println("cordinate value of j is=" + j + " and " + groupRect.get(j).getP1() + " "
					//		+ groupRect.get(j).getP2() + " " + groupRect.get(j).getP3() + " "
					//		+ groupRect.get(j).getP4());// v
					//System.out.println("cordinate value of k is=" + k + " and " + groupRect.get(k).getP1() + " "
						//	+ groupRect.get(k).getP2() + " " + groupRect.get(k).getP3() + " "
						//	+ groupRect.get(k).getP4());// v
					overlappedvaluefunc = overlap(groupRect.get(j), groupRect.get(k));// v
					//System.out.println("overlappedfuncvalue= " + overlappedvaluefunc);// v
					//////////////////////////////// //v
					cond = ((groupRect.get(j).getP4().y < groupRect.get(k).getP1().y
							|| groupRect.get(j).getP1().y > groupRect.get(k).getP4().y));// v
					//System.out.println("cond=" + cond);// v
				} // v
			} // v
				// d while (k < groupRect.size() &&
				// (Math.abs(groupRect.get(j).getP1().y -
				// groupRect.get(k).getP1().y) < 5
				// d || Math.abs(groupRect.get(j).getP4().y -
				// groupRect.get(k).getP4().y) < 5)) {
				// d k++;
				// d }
			noofrows.add(k - j);

			// with object oriented
			int putinrect = j;
			Row row = new Row();
			while (putinrect != k) {

				row.add(groupRect.get(putinrect));
				putinrect = putinrect + 1;
			}

			// subtablerow.add(rowlist);
			// object oreint
			subTable.add(row);
			j = k;
		}

		// for last rectangle
		if (j + 1 == groupRect.size()) {
			noofrows.add(1);
			Row row = new Row();
			row.add(groupRect.get(j));
			subTable.add(row);
		}

		System.out.println(subTable);
		
		//////////////////////printing each row ontaining how many columns
		//System.out.println("total no of rows in page is "+subTable.getNoOfRows());
	//	for(int i = 0;i<subTable.getNoOfRows();i++)
	//	{
	//		System.out.println(i +"th row contain "+subTable.getrow(i).getSize()+" rows");
	//	}
		return subTable;
	}

	/** defining the overlapping of columns in order to define rows */
	public static double overlap(RectAllPoint a1, RectAllPoint a2) {

		// check a1 inside a2 or equal
		if (a1.getP4().y >= a2.getP4().y && a1.getP1().y <= a2.getP1().y) {
			//System.out.println("j inside i");
			return 100;
		}
		// check a2 inside a1
		if (a2.getP4().y >= a1.getP4().y && a2.getP1().y <= a1.getP1().y) {
			//System.out.println("i inside j");
			return 100;
		}
		//System.out.println("some part overlapped");
		// find small height rectangle and calculate overlapping based on it
		double heighta1 = Math.abs(a1.getP1().y - a1.getP4().y);
		double heighta2 = Math.abs(a2.getP1().y - a2.getP4().y);
		//System.out.println("height a1 "+heighta1);
		//System.out.println("height a2 "+heighta2);
		double overlappedvalue=0;
		if(a1.getP4().y>= a2.getP4().y)
		{
			overlappedvalue = Math.abs(a1.getP1().y - a2.getP4().y);
		}
		else if (a1.getP4().y< a2.getP4().y)
		{
			overlappedvalue = Math.abs(a1.getP4().y - a2.getP1().y);
		}
		//overlappedvalue = Math.abs(a1.getP4().y - a2.getP1().y);
		//System.out.println("in function overlap value= " + overlappedvalue);
		if (heighta1 <= heighta2) {

			//System.out.println("in function if overlap value= " + 100 * overlappedvalue / heighta1);
			return 100 * overlappedvalue / heighta1;
		} else {
		//	System.out.println("in function else overlap value= " + 100 * overlappedvalue / heighta1);

			return 100 * overlappedvalue / heighta2;
		}

	}

	/** method to change from rect to rectallpoints */
	private static List<RectAllPoint> getAllpoints(List<Rect> listRect) {
		List<RectAllPoint> listOfRect = new ArrayList<RectAllPoint>();
		for (Rect rect : listRect) {
			Point p1 = rect.tl();
			Point p2 = rect.br();
			int width = rect.width;
			int height = rect.height;
			Point P1 = new Point(p1.x, p1.y);
			Point P2 = new Point(p1.x + width, p1.y);
			Point P3 = new Point(p2.x, p2.y);
			Point P4 = new Point(p1.x, p1.y + height);
			RectAllPoint rc = new RectAllPoint(P1, P2, P3, P4);
			rc.setHeight(height);
			rc.setWidth(width);
			listOfRect.add(rc);
		}
		return listOfRect;
	}

	/** recreating using the bounding box and the text */

	private static TablesInPage reCreateLayout(Size imgSize, FileTextInfo pageSize, TablesInPage listGroupedRects,
			List<FileTextInfo> listTextInfo, int type, String destinationDir, String fileName, int pageNo, Mat binary1) {
		// TablesInPage tablesInPage = new TablesInPage();
		Mat binary2=binary1.clone();
		double xScale = pageSize.getX2() / imgSize.width;
		double yScale = pageSize.getY2() / imgSize.height;

		Mat recreateImg = new Mat(imgSize, type);
		recreateImg = setBasicImageFeatures(recreateImg, recreateImg);
		Imgproc.cvtColor(recreateImg, recreateImg, Imgproc.COLOR_GRAY2BGR);
		Mat fileRect = recreateImg.clone();

		List<FileTextInfo> listTextInfocopy = listTextInfo;
		// sort listtextinfo based on p4.y cord
		Collections.sort(listTextInfocopy, new CompareFileList());
		/** trying to link text with co-ordinate...... */

		// list of rectangle from file
		List<RectAllPoint> rectpointoffile = new ArrayList<RectAllPoint>();
		// to remove the effect of eroding and dilating
		double apsilonx = 6.0;
		double apsilony = 5.0;
		// creating scaled co-ordinate of rectangle from file
		for (FileTextInfo text : listTextInfo) {
			Point p4 = new Point(text.getX1() / xScale - apsilonx, imgSize.height - (text.getY1() / yScale));
			Point p2 = new Point(text.getX2() / xScale + apsilonx, imgSize.height - (text.getY2() / yScale) + apsilony);
			Point p3 = new Point(p2.x, p4.y);
			Point p1 = new Point(p4.x, p2.y);
			int height = (int) Math.abs(p1.y - p4.y);
			int width = (int) Math.abs(p1.x - p2.x);
			RectAllPoint rc = new RectAllPoint(p1, p2, p3, p4);
			rc.setHeight(height);
			rc.setWidth(width);
			// System.out.println("Height:"+height+" ; width:"+width);
			TextInfo textInfo = new TextInfo();
			textInfo.setText(text.getText());
			textInfo.setFontFamily(text.getFontFamily());
			textInfo.setFontSize(text.getFontSize());
			rc.addTextInfo(textInfo);
			rectpointoffile.add(rc);

		}
		// sorting the rectangle co-ordinate from file based p4 point
		Collections.sort(rectpointoffile, new CompareRect());
		// testing
		for (int i = 0; i < rectpointoffile.size(); i++) {
			// int i=3;
			Imgproc.rectangle(fileRect, rectpointoffile.get(i).getP2(), rectpointoffile.get(i).getP4(),
					new Scalar(255, 0, 0));
			// Imgproc.putText(fileRect, rectpointoffile.get(i).getText(),
			// rectpointoffile.get(i).getP4(), 1, 0.85, new Scalar(255,0,0));
		}

		for (int m = 0; m < listGroupedRects.getNoOfTables(); m++) {
			for (int n = 0; n < listGroupedRects.getSubTable(m).getNoOfRows(); n++) {
				Row rectpoint = listGroupedRects.getSubTable(m).getrow(n);
				Collections.sort(rectpoint.row, new CompareRect());
			}
		}

		// testing
		// System.out.println("Listgrouped rects info:");
		// System.out.println("No of table:"+listGroupedRects.getNoOfTables());
		for (int m = 0; m < listGroupedRects.getNoOfTables(); m++) {
			// int m=8;
			// System.out.println("No of rows in table "+m+ " : " +
			// listGroupedRects.getSubTable(m).getNoOfRows());
			for (int n = 0; n < listGroupedRects.getSubTable(m).getNoOfRows(); n++) {
				// int m=1,n=0;
				Row rectpoint = listGroupedRects.getSubTable(m).getrow(n);
				// System.out.println("No of cols in row " + n + " : " +
				// rectpoint.getSize());
				for (int o = 0; o < rectpoint.getSize(); o++) {
					// System.out.println(rectpoint.getPoint(o).getP2());
					// System.out.println(rectpoint.getPoint(o).getP4());
					Imgproc.rectangle(fileRect, rectpoint.getPoint(o).getP2(), rectpoint.getPoint(o).getP4(),
							new Scalar(0, 0, 255));
				}
			}
		}
		// System.out.println("==========END============");
		Imgcodecs.imwrite(destinationDir + fileName + pageNo + "fileRect.jpg", fileRect);
		// List<RectAllPoint> rectpointoffile1 = rectpointoffile;
		/** placing the text in the corresponding rectangles */
		
		//System.out.println("===========================placing the text in the corresponding rectangles======================");
		for (int m = 0; m < listGroupedRects.getNoOfTables(); m++) 
		{
			 //int m=6;
			//System.out.println("for table no "+m+" ============= " );
		//	System.out.println("size of table as no of row is "+ listGroupedRects.getSubTable(m).getNoOfRows());
			for (int n = 0; n < listGroupedRects.getSubTable(m).getNoOfRows(); n++) {
				
				Row rectpoint = listGroupedRects.getSubTable(m).getrow(n);
			//	System.out.println("no of column in row  "+n+" "+rectpoint.getSize());
				for (int j = 0; j < rectpoint.getSize(); j++) {
				//	System.out.println("this is for "+ j+" th column in"+ n+ " row");
					Imgproc.rectangle(binary1, rectpoint.getPoint(j).getP2(), rectpoint.getPoint(j).getP4(),
							new Scalar(0, 0, 255));
					Imgcodecs.imwrite(destinationDir + fileName + pageNo + "missing.jpg", binary1);
					boolean flag=false;
					double overlappingThreshold1 = 50;
					for (int i = 0; i < rectpointoffile.size(); i++) {
					//	Imgproc.rectangle(binary2, rectpoint.getPoint(i).getP2(), rectpoint.getPoint(i).getP4(),
						//		new Scalar(0, 0, 255));
					//	Imgcodecs.imwrite(destinationDir + fileName + pageNo + "image.jpg", binary2);
				//		System.out.println("text of file box " +i +" is"+ rectpointoffile.get(i).getTextInfoList()+"===================");	
				//		System.out.println("cord of file box " +i +" is"+ rectpointoffile.get(i).getP1()+ " "+rectpointoffile.get(i).getP2()+" "+rectpointoffile.get(i).getP3()+" "+rectpointoffile.get(i).getP4());
				//		System.out.println("cord of image box " +j +" is"+ rectpoint.getPoint(j).getP1()+ " "+rectpoint.getPoint(j).getP2()+" "+rectpoint.getPoint(j).getP3()+" "+rectpoint.getPoint(j).getP4());
				//		System.out.println("\n");
						
///////////////////////////////////////////// based on overlapping
						boolean cond = true;// v
						cond = ((rectpoint.getPoint(j).getP4().y < rectpointoffile.get(i).getP1().y
								|| rectpoint.getPoint(j).getP1().y > rectpointoffile.get(i).getP4().y) || (rectpoint.getPoint(j).getP2().x < rectpointoffile.get(i).getP4().x
										|| rectpoint.getPoint(j).getP4().x > rectpointoffile.get(i).getP2().x) );
						
						if (!cond)
						{
						double overlappedvaluefunc = overlap(rectpoint.getPoint(j), rectpointoffile.get(i));
					//	System.out.println("overlapped value for mapping "+overlappedvaluefunc);
						
							if (overlappedvaluefunc>=overlappingThreshold1 &&  !rectpointoffile.get(i).isTextPlaced())
							{
						//		System.out.println("condition met in overlapped function in table "+ m+" in "+n +"th row\n");
								listGroupedRects.getSubTable(m).getrow(n).getPoint(j)
								.addTextInfoList(rectpointoffile.get(i).getTextInfoList());
								rectpointoffile.get(i).setTextPlaced(true);
							}
						}
						
						
/////////////////////////////////////////////			
						///////////////////////////////////////////////////////////divya code for mapping points
//						if ((Math.abs(rectpoint.getPoint(j).getP4().x - rectpointoffile.get(i).getP4().x) < 10
//								&& Math.abs(rectpoint.getPoint(j).getP4().y - rectpointoffile.get(i).getP4().y) <14)
//								&& (Math.abs(
//										rectpoint.getPoint(j).getWidth() - rectpointoffile.get(i).getWidth()) < 40)) {
//						//	flag=true;
//							// comparing the 2 rects with difference of 10px
//							// StringBuffer text = new StringBuffer(
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).getText());
//							// text.append("�").append(rectpointoffile.get(i).getText());
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).setText(text.toString());
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).setFontFamily(rectpointoffile.get(i).getFontFamily());
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).setFontSize(rectpointoffile.get(i).getFontSize());
//						//	System.out.println("condition met in if in table "+ m+" in "+n +"th row\n");
////							System.out.println("cord of file box is"+ rectpointoffile.get(i).getP1()+ " "+rectpointoffile.get(i).getP2()+" "+rectpointoffile.get(i).getP3()+" "+rectpointoffile.get(i).getP4());
////							System.out.println("cord of image box is"+ rectpoint.getPoint(j).getP1()+ " "+rectpoint.getPoint(j).getP2()+" "+rectpoint.getPoint(j).getP3()+" "+rectpoint.getPoint(j).getP4());
////							System.out.println("\n");
//							
//							listGroupedRects.getSubTable(m).getrow(n).getPoint(j)
//									.addTextInfoList(rectpointoffile.get(i).getTextInfoList());
//							// rectpointoffile.remove(i);
//							// i--;
//							
//						} else if (((rectpoint.getPoint(j).getP1().x <= rectpointoffile.get(i).getP1().x)
//								&& (rectpoint.getPoint(j).getP1().y <= rectpointoffile.get(i).getP1().y))
//								&& ((rectpoint.getPoint(j).getP3().x >= rectpointoffile.get(i).getP3().x)
//										&& (rectpoint.getPoint(j).getP3().y >= rectpointoffile.get(i).getP3().y))) {
//						//	flag=true;
//							// the text box falls inside the rect box
//							// mainly to group the textlines of the paragraph
//							// StringBuffer text = new StringBuffer(
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).getText());
//							// text.append("�").append(rectpointoffile.get(i).getText());
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).setText(text.toString());
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).setFontFamily(rectpointoffile.get(i).getFontFamily());
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).setFontSize(rectpointoffile.get(i).getFontSize());
////							System.out.println("text of file box is"+ rectpointoffile.get(i).getTextInfoList());
//						///	System.out.println("condition met in 1 else if in table "+ m+" in "+n +"th row\n");
////							System.out.println("cord of file box is"+ rectpointoffile.get(i).getP1()+ " "+rectpointoffile.get(i).getP2()+" "+rectpointoffile.get(i).getP3()+" "+rectpointoffile.get(i).getP4());
////							System.out.println("cord of image box is"+ rectpoint.getPoint(j).getP1()+ " "+rectpoint.getPoint(j).getP2()+" "+rectpoint.getPoint(j).getP3()+" "+rectpoint.getPoint(j).getP4());
////							System.out.println("\n");
//							listGroupedRects.getSubTable(m).getrow(n).getPoint(j)
//									.addTextInfoList(rectpointoffile.get(i).getTextInfoList());
//							// rectpointoffile.remove(i);
//							// i--;
//						} else if ((Math.abs(rectpoint.getPoint(j).getP3().x - rectpointoffile.get(i).getP3().x) < 10
//								&& Math.abs(rectpoint.getPoint(j).getP3().y - rectpointoffile.get(i).getP3().y) < 10)
//								&& (Math.abs(
//										rectpoint.getPoint(j).getWidth() - rectpointoffile.get(i).getWidth()) < 40)) {
//							//flag=true;
//							// comparing the 2 rects with difference of 10px
//							// StringBuffer text = new StringBuffer(
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).getText());
//							// text.append("�").append(rectpointoffile.get(i).getText());
//							//
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).setText(text.toString());
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).setFontFamily(rectpointoffile.get(i).getFontFamily());
//							// listGroupedRects.getSubTable(m).getrow(n).getPoint(j).setFontSize(rectpointoffile.get(i).getFontSize());
////							System.out.println("text of file box is"+ rectpointoffile.get(i).getTextInfoList());
//							//System.out.println("condition met in 2 else  if in table "+ m+" in "+n +"th row\n");
////							System.out.println("cord of file box is"+ rectpointoffile.get(i).getP1()+ " "+rectpointoffile.get(i).getP2()+" "+rectpointoffile.get(i).getP3()+" "+rectpointoffile.get(i).getP4());
////							System.out.println("cord of image box is"+ rectpoint.getPoint(j).getP1()+ " "+rectpoint.getPoint(j).getP2()+" "+rectpoint.getPoint(j).getP3()+" "+rectpoint.getPoint(j).getP4());
////							System.out.println("\n");
//							listGroupedRects.getSubTable(m).getrow(n).getPoint(j)
//									.addTextInfoList(rectpointoffile.get(i).getTextInfoList());
//							// rectpointoffile.remove(i);
//							// i--;
//						} //if(flag==true)break;
//						
//						
//						
						/////////////////////////////////////////////////////////// divya code for mapping points
					}

				}
			}
		}
		// System.out.println(listGroupedRects);
		// creating image
		for (int noOfTables = 0; noOfTables < listGroupedRects.getNoOfTables(); noOfTables++) {
			// int noOfTables=1;
			//System.out.println("This is table " + noOfTables);
			for (int noOfRow = 0; noOfRow < listGroupedRects.getSubTable(noOfTables).getNoOfRows(); noOfRow++) {
				// int noOfRow=1;
				for (int noOfCol = 0; noOfCol < listGroupedRects.getSubTable(noOfTables).getrow(noOfRow)
						.getSize(); noOfCol++) {
					// int noOfCol=0;
					Imgproc.rectangle(recreateImg,
							listGroupedRects.getSubTable(noOfTables).getrow(noOfRow).getPoint(noOfCol).getP2(),
							listGroupedRects.getSubTable(noOfTables).getrow(noOfRow).getPoint(noOfCol).getP4(),
							new Scalar(0, 0, 255));
					// String text =
					// listGroupedRects.getSubTable(noOfTables).getrow(noOfRow).getPoint(noOfCol)
					// .getText();
					// Imgproc.putText(recreateImg, text,
					// listGroupedRects.getSubTable(noOfTables).getrow(noOfRow).getPoint(noOfCol).getP4(),
					// 1,
					// 0.85, new Scalar(255, 0, 0));
					// System.out.println("corresponding text is " + text);
					for (TextInfo textInfo : listGroupedRects.getSubTable(noOfTables).getrow(noOfRow).getPoint(noOfCol)
							.getTextInfoList()) {
						String text = textInfo.getText();
						Imgproc.putText(recreateImg, text,
								listGroupedRects.getSubTable(noOfTables).getrow(noOfRow).getPoint(noOfCol).getP4(), 1,
								0.85, new Scalar(255, 0, 0));
					//	System.out.println("corresponding text is " + text);
					}
				}
			}
		}

		Imgcodecs.imwrite(destinationDir + fileName + "recreated.jpg", recreateImg);
		listGroupedRects.setHeight(imgSize.height);
		listGroupedRects.setWidth(imgSize.width);
		for (int m = 0; m < listGroupedRects.getNoOfTables(); m++) {
			for (int n = 0; n < listGroupedRects.getSubTable(m).getNoOfRows(); n++) {
				Row rectpoint = listGroupedRects.getSubTable(m).getrow(n);
				Collections.sort(rectpoint.row, new CompareXCols());
			}
		}
		listGroupedRects = getLineParams(listGroupedRects, destinationDir, fileName);
		return listGroupedRects;
	}

	/**
	 * mrthod to calculate wordlenratio, font ratio n other features
	 * 
	 * @param listGroupedRects
	 * @param destinationDir
	 * @param fileName
	 * @return
	 */
	private static TablesInPage getLineParams(TablesInPage listGroupedRects, String destinationDir, String fileName) {
		UtilityManager util = new UtilityManager();
		for (int i = 0; i < listGroupedRects.getNoOfTables(); i++) {
			SubTable subTable = listGroupedRects.getSubTable(i);
			for (int j = 0; j < subTable.getNoOfRows(); j++) {
				Row row = subTable.getrow(j);
				for (int k = 0; k < row.getSize(); k++) {
					RectAllPoint rect = row.getPoint(k);
					if (rect.getTextInfoList().size() > 0) {
						double fontSizeRatioPrev = 0.0;
						double fontSizeRatioNext = 0.0;
						double wordLenRatioPrev = 0.0;
						double wordLenRatioNext = 0.0;
						if (k != 0 && row.getPoint(k - 1).getTextInfoList().size() > 0) {
							fontSizeRatioPrev = rect.getTextInfoList().get(0).getFontSize()
									/ row.getPoint(k - 1).getTextInfoList().get(0).getFontSize();
							wordLenRatioPrev = (double) rect.getTextInfoList().get(0).getText().length()
									/ (double) row.getPoint(k - 1).getTextInfoList().get(0).getText().length();
						}
						if (k != row.getSize() - 1 && row.getPoint(k + 1).getTextInfoList().size() > 0) {
							fontSizeRatioNext = rect.getTextInfoList().get(0).getFontSize()
									/ row.getPoint(k + 1).getTextInfoList().get(0).getFontSize();
							wordLenRatioNext = (double) rect.getTextInfoList().get(0).getText().length()
									/ (double) row.getPoint(k + 1).getTextInfoList().get(0).getText().length();
						}
						if (k == 0 && row.getSize() == 1) {
							if ((j + 1) != subTable.getNoOfRows()) {
								if (j != 0 && subTable.getrow(j - 1).getSize() > 0
										&& subTable.getrow(j - 1).getPoint(0).getTextInfoList().size() > 0) {
									fontSizeRatioPrev = rect.getTextInfoList().get(0).getFontSize()
											/ subTable.getrow(j - 1).getPoint(0).getTextInfoList().get(0).getFontSize();
									wordLenRatioPrev = (double) rect.getTextInfoList().get(0).getText().length()
											/ (double) subTable.getrow(j - 1).getPoint(0).getTextInfoList().get(0)
													.getText().length();
								}
								if (subTable.getrow(j + 1).getSize() > 0
										&& subTable.getrow(j + 1).getPoint(0).getTextInfoList().size() > 0) {
									fontSizeRatioNext = rect.getTextInfoList().get(0).getFontSize()
											/ subTable.getrow(j + 1).getPoint(0).getTextInfoList().get(0).getFontSize();
									wordLenRatioNext = (double) rect.getTextInfoList().get(0).getText().length()
											/ (double) subTable.getrow(j + 1).getPoint(0).getTextInfoList().get(0)
													.getText().length();
								}
							} else {
								if ((i + 1) != listGroupedRects.getNoOfTables()) {
									if (i != 0 && listGroupedRects.getSubTable(i - 1).getNoOfRows() > 0
											&& listGroupedRects.getSubTable(i - 1)
													.getrow(listGroupedRects.getSubTable(i - 1).getNoOfRows() - 1)
													.getPoint(
															listGroupedRects.getSubTable(i - 1)
																	.getrow(listGroupedRects.getSubTable(i - 1)
																			.getNoOfRows() - 1)
																	.getSize() - 1)
													.getTextInfoList().size() > 0) {
										SubTable prevSubTable = listGroupedRects.getSubTable(i - 1);
										fontSizeRatioPrev = rect.getTextInfoList().get(0).getFontSize()
												/ prevSubTable.getrow(prevSubTable.getNoOfRows() - 1)
														.getPoint(prevSubTable.getrow(prevSubTable.getNoOfRows() - 1)
																.getSize() - 1)
														.getTextInfoList()
														.get(prevSubTable.getrow(prevSubTable.getNoOfRows() - 1)
																.getPoint(prevSubTable
																		.getrow(prevSubTable.getNoOfRows() - 1)
																		.getSize() - 1)
																.getTextInfoList().size() - 1)
														.getFontSize();
										wordLenRatioPrev = (double) rect.getTextInfoList().get(0).getText().length()
												/ (double) prevSubTable.getrow(prevSubTable.getNoOfRows() - 1)
														.getPoint(prevSubTable.getrow(prevSubTable.getNoOfRows() - 1)
																.getSize() - 1)
														.getTextInfoList()
														.get(prevSubTable.getrow(prevSubTable.getNoOfRows() - 1)
																.getPoint(prevSubTable
																		.getrow(prevSubTable.getNoOfRows() - 1)
																		.getSize() - 1)
																.getTextInfoList().size() - 1)
														.getText().length();
									}
									if (listGroupedRects.getSubTable(i + 1).getNoOfRows() > 0 && listGroupedRects
											.getSubTable(i + 1).getrow(0).getPoint(0).getTextInfoList().size() > 0) {
										SubTable nextSubTable = listGroupedRects.getSubTable(i + 1);
										fontSizeRatioNext = rect.getTextInfoList().get(0).getFontSize() / nextSubTable
												.getrow(0).getPoint(0).getTextInfoList().get(0).getFontSize();
										wordLenRatioNext = (double) rect.getTextInfoList().get(0).getText().length()
												/ (double) nextSubTable.getrow(0).getPoint(0).getTextInfoList().get(0)
														.getText().length();
									}
								}
							}
						}
						// System.out.println(rect.getTextInfoList().get(0).getText());
						rect.addParams(Constants.FONTSIZE_RATIO_PREV, fontSizeRatioPrev);
						rect.addParams(Constants.FONTSIZE_RATIO_NEXT, fontSizeRatioNext);
						rect.addParams(Constants.WORDLEN_RATIO_PREV, wordLenRatioPrev);
						rect.addParams(Constants.WORDLEN_RATIO_NEXT, wordLenRatioNext);
						String desc = util.removeStopWords(rect.getTextInfoList().get(0).getText());
						int caps = util.checkForCapital(desc);
						int bold = util.checkForBold(rect.getTextInfoList().get(0).getFontFamily());
						rect.addParams(Constants.BOLD_TEXT, bold);
						rect.addParams(Constants.CAPITAL_TEXT, caps);
						String value = checkForHeadings(rect.getParams(), destinationDir, fileName);
						if (value.length() > 0 && !value.equals("none")) {
							rect.setHasHeading(true);
							rect.getTextInfoList().get(0).setHeading(true);
							rect.getTextInfoList().get(0).setHeadingType(value);
						}
					}
				}
			}
		}
		return listGroupedRects;
	}

	/**
	 * Invoking ML model for heading detection
	 * 
	 * @param params
	 * @param destinationDir
	 * @param fileName
	 * @return
	 */
	private static String checkForHeadings(Map<String, Double> params, String destinationDir, String fileName) {
		Classification classifier = new Classification();
		String value = "";
		try {
			value = classifier.extractCategory(params.toString().replace("{", "").replace("}", ""),
					destinationDir + fileName + "_test.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return value;
	}

	/**
	 * @param srcImgMat
	 * @param destImgMat
	 * @return
	 */
	private static Mat setBasicImageFeatures(Mat srcImgMat, Mat destImgMat) {
		// converting image to gray
		Imgproc.cvtColor(srcImgMat, srcImgMat, Imgproc.COLOR_RGB2GRAY);
		/**
		 * black and white binary image ADAPTIVE_THRESH_MEAN_C - threshold val
		 * is mean of blocksize blocksize - decides the size of neighborhood
		 * area C- constant to be subtracted from the mean calculated
		 */
		Imgproc.adaptiveThreshold(srcImgMat, destImgMat, Constants.MAXVAL, Imgproc.ADAPTIVE_THRESH_MEAN_C,
				Imgproc.THRESH_BINARY, Constants.BLOCK_SIZE, Constants.C);
		return destImgMat;
	}
//36, 36_image, 77, 77_image, 121, 121_image, 143, 143_image, 1000111813 _2017_CR, 1000111813 _2017_CR_image, CCDS_Dexlansoprazole_20130816_v3.0, CCDS_Dexlansoprazole_20130816_v3.0_image,
	// page2, page2_image,term6 , term6_image 
	
	public static void main(String[] args) {
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		String sourceDir = ConfigFileLoader.getSourceDir();
		String pdfFileName = "36_image";
		// String pdfFileName = "CCDS_Dexlansoprazole_20130816_v3.0";
		ConvertPDFToImages pdftoimg = new ConvertPDFToImages();
		int noPages = pdftoimg.pdfToImage(sourceDir, pdfFileName);
		System.out.println("Number of pages in PDF:" + noPages);
		if (noPages > 0) {
			Map<Integer, Object> pdfContent = new HashMap<Integer, Object>();
			String destinationDir = sourceDir + pdfFileName + "/";
			/** get coordinates of text */
			ExecuteCommand cmd = new ExecuteCommand();
			try {
				// invoking python code
				cmd.execute(sourceDir, pdfFileName, destinationDir);
			} catch (IOException | InterruptedException e) {
				e.printStackTrace();
			}
			// reading from the coordinates file
			String cordFile = destinationDir + ConfigFileLoader.getPythonOutPutFile();
			File file = new File(cordFile);
			if (file.exists()) {
				ReadFile rf = new ReadFile();
				List<PDFPage> pageTextList = rf.readFile(cordFile);

				for (int page = 1; page <= noPages; page++) {
					List<FileTextInfo> listTextInfo = pageTextList.get(page - 1).getPageTextList();
					String imgFileName = pdfFileName + "_" + page;
					// whole page in tables and subtables format
					TablesInPage pageContent = processLayout(sourceDir, destinationDir, pdfFileName, imgFileName,
							listTextInfo, page);
					pdfContent.put(page, pageContent);
				}
				//print(pdfContent, pdfFileName);
				boolean status = createHtml(pdfContent, destinationDir, pdfFileName);
				if (status) {
					System.out.println("Successfully created html output");
				} else {
					System.err.println("Failed to create the html output. Please check.");
				}
			} else {
				System.out.println("Cords file not found. Please Check to proceed and rerun");
			}
		} else {
			System.out.println("There were no pages found in the file. Please check and rerun");
		}

	}

	private static void print(Map<Integer, Object> pdfContent, String pdfFileName) {
		File file = new File("D:\\Divya\\OCRParser\\pdflatest\\testing\\trainingfile\\" + pdfFileName + ".txt");
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(file));
			for (Entry<Integer, Object> entry : pdfContent.entrySet()) {
				TablesInPage tables = (TablesInPage) entry.getValue();
				for (int i = 0; i < tables.getNoOfTables(); i++) {
					SubTable subtable = tables.getSubTable(i);
					for (int j = 0; j < subtable.getNoOfRows(); j++) {
						Row row = subtable.getrow(j);
						for (int k = 0; k < row.getSize(); k++) {
							RectAllPoint rect = row.getPoint(k);
							// System.out.println(rect.getParams());
							// System.out.println(rect.getTextInfoList());
							// System.out.println("----------");
							bw.write(rect.getParams().toString() + "\n");
							bw.write(rect.getTextInfoList().toString() + "\n");
							bw.write("----------" + "\n");
						}
						// System.out.println("=================");
						bw.write("=================" + "\n");
					}
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				bw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * Calling html writer to get the html content
	 * 
	 * @param pdfContent
	 * @param pdfFileName
	 * @param destinationDir
	 * @return
	 */
	private static boolean createHtml(Map<Integer, Object> pdfContent, String destinationDir, String pdfFileName) {
		boolean status = false;
		HTMLWriterNew htmlWriter = new HTMLWriterNew();
		String content = htmlWriter.createHTML(pdfContent);
		// writing html content into file
		try {
			File outputFile = new File(destinationDir + pdfFileName + ".html");
			BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile));
			bw.write(content);
			bw.close();
			status = true;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return status;
	}

}
