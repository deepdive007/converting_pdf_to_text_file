package com.cognizant.model;

import java.util.ArrayList;
import java.util.List;

public class Row {
//content of each row
	public List<RectAllPoint> row;

	public Row() {
		this.row = new ArrayList<RectAllPoint>();
	}

	public void add(RectAllPoint rct) {
		this.row.add(rct);
	}

	public int getSize() {
		return this.row.size();

	}

	public RectAllPoint getPoint(int colno) {
		return this.row.get(colno);

	}

	// method added by 459090
	public void clearRow() {
		row.clear();
	}

	// method added by 459090
	@Override
	public String toString() {
		return "Row [row=" + row + "]";
	}

}
