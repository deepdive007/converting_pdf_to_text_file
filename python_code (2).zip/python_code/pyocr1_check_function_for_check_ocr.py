import pyocr1
import os
import glob
import cv2
from PIL import Image
import numpy as np
def processing_image(image,full_path,pageno,cordinates_text,image_cordinate):

	print("ocr initializing.......")
	tool,lang=pyocr1.initiatePyocr()
	#print("ocr initialized")

	#image='1_Im1.jpg'
	#text=pyocr1.printonlytext(tool,lang,image)
	#image=glob.glob("path/to/folder/*.png")
	#print("full_path =",full_path)
	#print("imagenam===",image)
	#print("os path",os.path)
	os.chdir(full_path)
	#print("directory ",os.getcwd())
	#image =glob.glob("D:\imagepro\pdf_file_having_jpeg_image\pdf_file_having_jpeg_image.pdf\1_Image9.jpg")
	#if image is not None:
	#	print("exist",image)
	#image=open(os.path.join(folder, filename))
	#if image=='1_Image9.jpg':
		#print("image exist")

	word_boxes,image_size=pyocr1.wordandcordinate(tool,lang,image,cordinates_text)
	#os.chdir('D:/')
	#print("=====================================")
	############################ add into cordfuncnew file
	#print("image exist at this cordinates in pdf ===",image_cordinate)
	#print("image exist at this cordinates in pdf have scaled to image_size ===",image_size)
	ImageWidth=image_cordinate[2]-image_cordinate[0];
	ImageHeight=image_cordinate[3]-image_cordinate[1];
	#print("ImageWidth===",ImageWidth)
	#print("ImageHeight===",ImageHeight)
	xscale=image_size[0]/ImageWidth;
	yscale=image_size[1]/ImageHeight;
	#print("xscale===",xscale)
	#print("yscale===",yscale)
	#img = Image.new('RGB', (612,792), (255, 255, 255))
	## to check image generation
	#img = np.ones([792, 612, 3], dtype=np.uint8)
	#img[:,:,:]=255
	#cv2.imwrite("image.jpg", img)
	#img = cv2.imread("image.jpg")
	
	for word in word_boxes:
		x1=image_cordinate[0]+(word.position[0][0]/xscale)
		y2=image_cordinate[1]+((image_size[1]-word.position[0][1])/yscale)
		x2=image_cordinate[0]+(word.position[1][0]/xscale)
		y1=image_cordinate[1]+((image_size[1]-word.position[1][1])/yscale)
		l=[]
		l.append("("+str(x1)+", "+str(y1)+", "+str(x2)+", "+str(y2)+")")
		l.append("")
		l.append(str((y2-y1)))
		l.append(str(word.content)+"\n")
		if word.content!="":
			cordinates_text.append(l);
		#img = cv2.rectangle(img,(int(x1),int(y1)),(int(x2),int(y2)),(255,0,0),2)
	#################################
	
#	cv2.imwrite(str(pageno)+"check_full_page.jpg",img)
	filename=image+str(pageno)+'.txt';
	pyocr1.Writecordinate(filename,word_boxes,image)
	return cordinates_text
