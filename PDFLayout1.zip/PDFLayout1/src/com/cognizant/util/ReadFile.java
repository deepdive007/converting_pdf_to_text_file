package com.cognizant.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Stream;

import com.cognizant.model.FileTextInfo;
import com.cognizant.model.PDFPage;

public class ReadFile {

	/**
	 * read the python code output file and put the values into object
	 * @param fileName
	 * @return
	 */
	public List<PDFPage> readFile(String fileName) {
		// each page
		List<PDFPage> pageList = new ArrayList<PDFPage>();
		// list of info for each page
		List<FileTextInfo> listFileText = new ArrayList<FileTextInfo>();
		try {
			BufferedReader br = Files.newBufferedReader(Paths.get(fileName), StandardCharsets.UTF_8);
			//reading the lines
			Stream<String> lines = br.lines().map(str -> str);
			Iterator<String> iter = lines.iterator();
			int pageNo = 0;
			
			while (iter.hasNext()) {
				String content = iter.next();
				if (!content.equalsIgnoreCase(Constants.NEXT_PAGE)) {
					//if not next page put the info into textInfo obj
					FileTextInfo textInfo = new FileTextInfo();
					//get coordinates
					textInfo.setCoordinates(content);
					// corresponding text
					textInfo.setFontFamily(iter.next());
					String fontSize = iter.next();
					if(null!=fontSize&&fontSize.trim().length()>0)
						textInfo.setFontSize(Double.valueOf(fontSize));
					textInfo.setText(iter.next());
					listFileText.add(textInfo);
					iter.next();
				} else {
					// next page create PDFPage and set textinfo 
					PDFPage page = new PDFPage();
					page.setPageNo(++pageNo);
					page.setPageTextList(listFileText);
					pageList.add(page);
					// one page done
					// for next page reinitialize listFileText 
					listFileText = new ArrayList<FileTextInfo>();
					if (iter.hasNext())
						iter.next();
				}
			}

			lines.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
		return pageList;
	}

	// public static void main(String[] args) {
	// String filename = "D:/Divya/OCRParser/working/IMAGES/cords.txt";
	// ReadFile rf = new ReadFile();
	// System.out.println(rf.readFile(filename));
	// }
}
